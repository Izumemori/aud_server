/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef VIEW_HPP
#define VIEW_HPP

#include <string>
#include "xeus/xjson.hpp"
#include "nlohmann/json.hpp"
#include "AlgoViz.hpp"

using namespace std;

/**
 * \class AlgoVizView View.hpp algoviz/AlgoViz.hpp
 * \brief An abstract View in the AlgoViz sidebar.
 * 
 * The size of views is either given in grid rows and columns (both 60 pixels wide)
 */
class AlgoVizView {
    
    protected:
        /// @private
        int id;
        /// @private
        string type;
        /// @private
        int rowHeight = 60;
        /// @private
        int colWidth = 60;

    public:
        /**
         * \brief Create a view in the AlgoViz sidebar.
         * This constructor creates a view in the AlgoViz sidebar. The size is either given
         * in grid coumns and rows or pixels, depending on the type of view.
         * @param width The width of the view.
         * @param height The height of the view.
         */
        /// @private
        void create(int width, int height) {
            this->id = algoviz::nextViewID;
            algoviz::nextViewID++;

            auto msg = xeus::xjson::object();
            msg["type"] = this->type;
            msg["cmd"] = "create";
            msg["width"] = width;
            msg["height"] = height;
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }


        /**
         * Hide the view.
         * Remove the view from the AlgoViz sidebar. It is not
         * disposed and can still be manipulated and shown again.
         */
        void hide() {
            auto msg = xeus::xjson::object();
            msg["type"] = this->type;
            msg["cmd"] = "hide";
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }

        /**
         * Show the view.
         */ 
        void show() {
            auto msg = xeus::xjson::object();
            msg["type"] = this->type;
            msg["cmd"] = "show";
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }

        /**
         * Clear the view.
         */ 
        void clear() {
            auto msg = xeus::xjson::object();
            msg["type"] = this->type;
            msg["cmd"] = "clear";
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }
}; // class AlgoVizView


/**
 * \class HTML HTML.hpp algoviz/AlgoViz.hpp
 * \brief A view for HTML in the AlgoViz sidebar.
 * 
 * The size of views is given in grid rows and columns (both 60 pixels wide)
 * 
 * To add a view and set its content use:
 * 
 *     HTML view = HTML2,1);
 *     view.set("<b>Bold</b> and <i>italic</i> text.");
 * 
 * The content is given as an [HTML string](https://wiki.selfhtml.org/).
 */
class HTML : public AlgoVizView {

    public:
        /**
         * \brief Add an HTML view.

         * @param width The width of the view in grid colkumns.
         * @param height The width of the view in grid colkumns.
         */
        HTML(int width, int height) {
            this->type = "view";
            this->create(width,height);
        }

        /**
         * \brief Set the content of the view.
         * It is given as an HTMNL string.
         *     view.set("<b>This text is bold.</b> <i>This one in italics.</i>")
         * @param content The new content as an HTML string.
         */
        void set(const std::string& content) {
            auto msg = xeus::xjson::object();
            msg["type"] = "view";
            msg["cmd"] = "set";
            msg["content"] = content;
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }

        /**
         * Append content to the view.
         * 
         * @param content The content to be appended as an HTML string.
         */
        void append(const std::string& content) {
            auto msg = xeus::xjson::object();
            msg["type"] = "view";
            msg["cmd"] = "add";
            msg["content"] = content;
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }

        /**
         * Set an attribute of the HTML view.
         * 
         * Among the possible attributes are
         * * backgroundColor, e.g. "red", "green", "#FF00FF", "rgb(100,200,50)"
         * * color, e.g. "red", "green", "#FF00FF", "rgb(100,200,50)"
         * 
         * @param name The attribute to be set.
         * @param value The value of the attribute.
         */
        void setAttribute(const std::string& name,const std::string& value) {
            auto msg = xeus::xjson::object();
            msg["type"] = "view";
            msg["cmd"] = "style";
            msg["name"] = name;
            msg["value"] = value;
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }


        /**
         * Set an attribute of the HTML view.
         * 
         * Among the possible attributes are
         * * backgroundColor, e.g. "red", "green", "#FF00FF", "rgb(100,200,50)"
         * * color, e.g. "red", "green", "#FF00FF", "rgb(100,200,50)"
         * 
         * @param name The attribute to be set.
         * @param value The value of the attribute.
         */
        void setAttribute(const std::string& name, int value) {
            auto msg = xeus::xjson::object();
            msg["type"] = "view";
            msg["cmd"] = "style";
            msg["name"] = name;
            msg["value"] = value;
            msg["id"] = this->id;
            AlgoViz::sendMsg(msg);
        }
};

#endif