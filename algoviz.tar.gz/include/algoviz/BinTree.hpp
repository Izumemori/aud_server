/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik->
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software->
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT-> IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE->
 */

#ifndef BINTREE_HPP
#define BINTREE_HPP

#include <vector>
#include <map>
#include <string>
#include "SVG.hpp"
#include <iostream>

using namespace std;

template<typename T> class NodeView;
template<typename T> class ConnectionView;
template<typename T> class BinTreeView;

 /**
  * \class BinTree
  * \brief A simple implementation of a binary tree->
  */
 template<typename T> class BinTree {

    friend class NodeView<T>;
    friend class ConnectionView<T>;
    friend class BinTreeView<T>;

    protected:
        /// @private
        T value;
        /// @private
        BinTree<T> *leftChild;
        /// @private
        BinTree<T> *rightChild;
        /// @private
        BinTree<T> *parent;
        /// @private
        NodeView<T> *view;
        /// @private
        map<string,string> *attributes;


    public:

        /**
         * \brief Create a node of a binary tree
         */
        BinTree( T value, BinTreeView<T> *treeView = nullptr) {
            this->value = value;
            this->leftChild = nullptr;
            this->rightChild = nullptr;
            this->parent = nullptr;

            this->view = nullptr;
            if ( treeView != nullptr ) {
                this->view = treeView->addNode(this);
            }

            this->attributes = new map<string,string>();
            (*this->attributes)["stroke"] = "black";
            (*this->attributes)["text-color"] = "black";
            (*this->attributes)["color"] = "white";
        }

        /**
         * \brief Check if the node is a root
         * 
         * @returns{boolean} true if the node is a root
         */
        inline bool isRoot() {
            return ( this->parent == nullptr );
        }

        /**
         * \brief Check if the node has a left child
         * 
         * @returns{boolean} ture, wenn ein linkes Kind existiert
         */
        inline bool hasLeftChild() {
            return ( this->leftChild != nullptr );    
        }

        /**
         * \brief Check if the node has a left child
         * 
         * @returns{boolean} ture, wenn ein linkes Kind existiert
         */
        inline bool hasRightChild() {
            return ( this->rightChild != nullptr );    
        }

        /**
         * \brief Check if the node is a leaf
         * 
         * @returns{boolean} ture, wenn er ein Blatt ist
         */
        inline bool isLeaf() {
            return ( (this->rightChild == nullptr) && (this->leftChild == nullptr) );    
        }


        /**
         * \brief Gets the value.
         */
        T getValue() {
            return this->value;
        }


        /**
         * \brief Get the parent
         * 
         * @returns{BinTree<T>} ThepParent
         */
        BinTree<T> *getParent() {
            return this->parent;
        }

        /**
         * \brief Get the left child
         * 
         * @returns{BinTree<T>} The left child
         */
        BinTree<T> *getLeftChild() {
            return this->leftChild;
        }


        /**
         * \brief Get the right child
         * 
         * @returns{BinTree<T>} The right child
         */
        BinTree<T> *getRightChild() {
            return this->rightChild;
        }


        /**
         * \brief set the left child
         * 
         * @param left The left child
         */
        void setLeftChild(BinTree<T> *left) {
            // Disconnect current left child

            if ( this->leftChild != nullptr ) this->leftChild->disconnect();

            if ( left == nullptr ) {
                this->leftChild = nullptr;
                return;
            }

            left->disconnect();

            this->leftChild = left;
            left->parent = this;

            if ( this->view != nullptr ) {
                this->view->setLeftChild(left);
            }
        }


        /**
         * \brief set the right child
         * 
         * @param right The right child
         */
        void setRightChild(BinTree<T> *right) {

            // Disconnect right child
            if ( this->rightChild != nullptr ) this->rightChild->disconnect();

            if ( right == nullptr ) {
                this->rightChild = nullptr;
                return;
            }

            right->disconnect();

            this->rightChild = right;
            right->parent = this;

            if ( this->view != nullptr ) {
                this->view->setRightChild(right);
            }
        }


        /**
         * \brief Disconnect node from parent.
         * 
         * The node becomes a root.
         */
        void disconnect() {
            if ( this->parent != nullptr ) {
                if ( this == this->parent->leftChild ) {
                    this->parent->leftChild = nullptr;
                } else {
                    this->parent->rightChild = nullptr;
                }
            }
            this->parent = nullptr;

            if ( this->view != nullptr ) this->view->disconnect();
        }


        /**
         * \brief Sets attributes of the visualization
         * "color" - color of the nodes text
         * "stroke" - color of the nodes border
         * "fill" - color of the node
         * "label" - label text
         * "label-color" - color of the label text
         * 
         * Additional attributes can be used for algorithmic purposes
         * 
         * @param attr The name of the attribute
         * @param value The value of the attribute
         */
        void setAttribute(string attr, string value) {      
            this->attributes[attr] = value;
            if ( this->view ) {
                this->view->update(this);
            }  
        }

        /**
         * \brief Get a specific attribute
         * 
         * @param attr The attributes name
         */
        string getAttribute(string attr) {
            return this->attributes[attr];
        }
};


/**
 * \class NodeView
 * \brief A node of a binary tree
 * 
 * It manages the SVG \ref Group representing the node.
 * It also manages the connections to its childen.
 */
template<typename T> class NodeView : public Group {

    friend class ConnectionView<T>;
    friend class BinTreeView<T>;

    protected:
        /// @private
        BinTree<T> *node;
        /// @private
        BinTreeView<T> *treeView;
        /// @private
        Circle *circle;
        /// @private
        Text *text;
        /// @private
        Text *label;
        /// @private
        int x;
        /// @private
        int y;
        /// @private
        int radius;
        /// @private
        ConnectionView<T> *leftConn;
        /// @private
        ConnectionView<T> *rightConn;
        /// @private
        ConnectionView<T> *parentConn;


        /**
         * \brief Update the view
         */
        void update() {
            // Apply the attributes
            this->circle->setAttribute("stroke",(*this->node->attributes)["stroke"]);
            this->circle->setAttribute("fill",(*this->node->attributes)["color"]);
            this->text->setAttribute("fill",(*this->node->attributes)["text-color"]);
            this->label->setText((*this->node->attributes)["label"]);
            this->label->setAttribute("fill",(*this->node->attributes)["label-color"]);
            this->text->setText(std::to_string(this->node->value));            
        }

    public:
        /**
         * \brief Create a view for a BinTree
         * 
         * @param v The BinTree
         */
        NodeView(BinTree<T> *v, int x, int y, int radius, BinTreeView<T> *view) : Group(view) {
            this->x = x;            
            this->y = y;
            this->radius = radius;
            this->node = v;
            this->treeView = view;

            this->circle = new Circle(0,0,this->radius,this->treeView);
            this->add(this->circle);

            this->circle->setAttribute("fill","white");
            this->circle->setAttribute("stroke-width","1");
        
            this->label = new Text("",0.75*this->radius,-0.75*this->radius,this->treeView);
            this->add(this->label);

            this->text = new Text(std::to_string(this->node->value),0,0,this->treeView);
            this->add(this->text);

            this->text->setAttribute("alignment-baseline","central");
            this->text->setAttribute("text-anchor","middle");
            this->text->setAttribute("font-size",""+ std::to_string(this->radius)+"px");

            this->leftConn = new ConnectionView<T>(this,nullptr,this->treeView);
            this->rightConn = new ConnectionView<T>(this,nullptr,this->treeView);
            this->parentConn = nullptr;
        }


        ~NodeView() {
            this->leftConn->removeFromView();
            this->rightConn->removeFromView();
            this->removeFromView();

            delete this->leftConn;
            delete this->rightConn;
        }


        /**
         * \brief Add the NodeView to an SVG View
         * 
         * @param view The view
         */
        // void addTo(AlgoVizView *view ) {
        //     Group::add(view);
        //     this->moveTo(this->x,this->y);
        // }


        /**
         * \brief Set the label of the node
         * 
         * @param label The label
         */
        void setLabel(string label) {
            this->label->setText(label);

            this->label->setAttribute("alignment-baseline","central");
            this->label->setAttribute("text-anchor","middle");
            this->label->setAttribute("font-size",""+this->radius+"px");
        }


        /**
         * \brief Set the text of the node
         * 
         * @param label The text
         */
        void setText(string label) {
            this->text->setText(label);

            this->text->setAttribute("alignment-baseline","central");
            this->text->setAttribute("text-anchor","middle");
            this->text->setAttribute("font-size",""+this->radius+"px");
        }


        /**
         * \brief Set the position of the node
         * 
         * @param x The x-coordinate
         * @param y The y-coordinate
         */
        void setPosition( int x, int y) {
            this->x = x;
            this->y = y;

            this->moveTo(this->x,this->y);

            this->leftConn->update();
            this->rightConn->update();
            
            if ( this->parentConn != nullptr ) this->parentConn->update();
        }


        /**
         * \brief Set the left child of the view.
         * 
         * @param left The left child
         */
        void setLeftChild(BinTree<T> *left) {     

            if ( (this->leftConn->child != nullptr) && (left == this->leftConn->child->node)) {
                return;
            }

            if ( this->leftConn->child != nullptr ) {                
                this->leftConn->child->disconnect();
            }

            // left has no view
            if ( left->view == nullptr ) {
                left->view = this->treeView->addNode(left);
            } else if ( left->view->treeView != this->treeView ) {
                // Move left to view.
                // Delete from old view
                left->view->removeFromView();
                delete left->view;
                // Create new view
                left->view = this->treeView->addNode(left);
            }

            if ( left->view->parentConn != nullptr ) {
                left->view->disconnect();
            }

            // Now they are in the same view
            // Set connection
            this->leftConn->setChild(left->view);
            this->treeView->layout();
        }


        /**
         * \brief Set the right child of the view.
         * 
         * @param right The right child
         */
        void setRightChild(BinTree<T> *right) {
            if (  (this->rightConn->child != nullptr) && (right == this->rightConn->child->node)) {
                return;
            }

            if ( this->rightConn->child != nullptr ) {
                this->rightConn->child->disconnect();
            }

            // right has no view
            if ( right->view == nullptr ) {
                right->view = this->treeView->addNode(right);
            } else if ( right->view->treeView != this->treeView ) {
                // Move right to view.
                // Delete from old view
                right->view->removeFromView();
                delete right->view;
                // Create new view
                right->view = this->treeView->addNode(right);
            }

            if ( right->view->parentConn != nullptr ) {
                right->view->disconnect();
            }

            // Now they are in the same view
            // Set connection
            this->rightConn->setChild(right->view);
            this->treeView->layout();
        }


        /**
         * \brief Disconnect the node from its parent.
         */
        void disconnect() {
            std::cout << "Disconnect " << std::to_string(this->node->value) << endl;
            if ( this->parentConn != nullptr ) {
                this->parentConn->setChild(nullptr);
            }
            this->parentConn = nullptr;
            this->update();
        }
};



/**
 * \class ConnectionView
 * 
 * \brief An edge between vertices. 
 * 
 * It is hidden, if one of the ends is nullptr.
 */
template<typename T> class ConnectionView : public Group {

    friend class NodeView<T>;
    friend class BinTreeView<T>;

    protected:
        /// @private
        NodeView<T> *parent;
        /// @private
        NodeView<T> *child;
        /// @private
        BinTreeView<T> *treeView;
        /// @private
        Line *line;
        /// @private
        Text *label;

        /// @private
        void update() {
            if ( (this->parent == nullptr) || (this->child == nullptr) ) {
                this->hide();
            } else {
                this->show();
                this->line->setAttribute("x1",this->parent->x);
                this->line->setAttribute("y1",this->parent->y);
                this->line->setAttribute("x2",this->child->x);
                this->line->setAttribute("y2",this->child->y);
                this->label->setAttribute("x",(this->parent->x+this->child->x)/2);
                this->label->setAttribute("y",(this->parent->y+this->child->y)/2);
                this->parent->toFront();
                this->child->toFront();
            }
        }

    public:

        /**
         * \brief Create an edge between two nodes
         * 
         * @param parent The parent node
         * @param child The child node
         * @param view The view
         */
        ConnectionView(NodeView<T> *parent, NodeView<T> *child, BinTreeView<T> *treeView) : Group(treeView) {
            this->parent = parent;
            this->child = child;
            this->treeView = treeView;

            this->line = new Line(0,0,0,0,treeView);
            this->add(this->line);
    
            this->label = new Text("",0,0,treeView);
            this->add(this->label);

            this->update();
        }


        /**
         * \brief Set the edge label
         * 
         * @param label The label
         */
        void setLabel(string label) {
            this->label->setText(label);
            this->update();
        }


        /**
         * \brief Change the child of the onnection.
         */
        void setChild(NodeView<T> *child) {
            this->child = child;
            if ( child != nullptr ) child->parentConn = this;
            this->update();
        }
};



/// @private
/**
 * The layout struct
 */
template <typename T> struct layout_t {
    int x;
    int y;
    int shift;
    int w;
    NodeView<T>* view;
};


/**
 * \class BinTreeView
 * \brief The view of the graph (undirected)
 */
template<typename T> class BinTreeView : public SVG {

    friend class NodeView<T>;
    friend class ConnectionView<T>;

    protected:
        vector<NodeView<T>*> *nodes;
        vector<ConnectionView<T>*> *edges;
        int delta = 30;


    public:
        /**
         * \brief Create an empty view.
         */
        BinTreeView(int width, int height, int gw, int gh) : SVG(width,height,gw,gh) {
            this->nodes = new vector<NodeView<T>*>;
            this->edges = new vector<ConnectionView<T>*>;
        }

        /**
         * \brief Add a node to the view.
         * 
         * @param node The node to be added.
         * 
         * @returns The \ref NodeView of the new node.
         */
        NodeView<T> *addNode(BinTree<T> *node) {
            NodeView<T> *view;

            if ( node->view != nullptr ) {
                node->view->hide();
                delete node->view;
            }

            view = new NodeView<T>(node,0,0,10,this);
            this->nodes->push_back(view);

            this->layout();

            return view;
        }

        /**
         * \brief Layout the binary tree.
         */
        void layout() {
            int x = 0;
            int y = 0;

            for ( int i = 0; i < this->nodes->size(); i++ ) {
                NodeView<T> *nv = (*this->nodes)[i];
                if ( nv->node->isRoot() ) {
                    layout_t<T> *lay = this->layoutTree(nv,x,y);
                    x += this->delta + lay->w;
                }
            }

            int xOff = (this->getWidth()-x)/2;
            if ( xOff < 0 ) xOff = 0;
            this->setViewBox(-xOff,-this->delta/2,this->getWidth()+this->delta,this->getHeight());
            // this->setViewBox(-this->delta/2,-this->delta/2,x+this->delta/2,this->getHeight());
        }


        /**
         * \brief Laying out a tree.
         * 
         * @param node The root of the tree to be layouted
         * @param x The x-coordinate of the upper left corner of the bounding box
         * @param y The y-coordinate of the upper left corner of the bounding box
         */
    layout_t<T> *layoutTree(NodeView<T> *node,int  x,int y) {
        layout_t<T> *layout =  new layout_t<T>();
        layout->w = 0;
        layout->shift = 0;
        layout->view = nullptr;

        if ( node == nullptr) { 
            return layout;
        }

        ConnectionView<T> *ev;
        NodeView<T> *child;

        layout_t<T> *lLayout = new layout_t<T>();
        lLayout->w = 0;
        lLayout->shift = 0;
        lLayout->view = nullptr;

        layout_t<T> *rLayout = new layout_t<T>();
        rLayout->w = 0;
        rLayout->shift = 0;
        rLayout->view = nullptr;

        int skip = this->delta;

        if ( node->leftConn->child != nullptr ) {
            lLayout = this->layoutTree(node->leftConn->child,x,y+3*this->delta/2);
        } else {
            skip = this->delta;
        }

        if ( node->rightConn->child != nullptr ) {
            rLayout = this->layoutTree(node->rightConn->child,x+skip+lLayout->w,y+3*this->delta/2);
        } else {
            skip = this->delta;
        }

        layout->shift = (lLayout->shift + lLayout->w + skip + rLayout->shift)/2;
        layout->w = lLayout->w + skip + rLayout->w;

        node->setPosition(x + layout->shift,y);

        return layout;
    }

    /*
    void add( SVGElement *element) {
        this->view->add(element);
    }


    NodeView<T> *findView(BinTree<T> *node) {
        for ( int i = 0; i < this->vertices->length; i++ ) {
            if ( this->vertices[i]->node == node ) return this->vertices[i];
        }
        return nullptr;
    }


    void update(BinTree<T> *node) {
        NodeView<T> *nv = this->findView(node);
        if ( nv ) {
            nv->update();
        }
    }
    */
};



#endif