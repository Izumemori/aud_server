/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef SVG_HPP
#define SVG_HPP

#include <iostream>
#include <string>
#include "xeus/xjson.hpp"
#include "nlohmann/json.hpp"
#include <algoviz/AlgoViz.hpp>

using namespace std;

class AlgoViz;
class SVG;

class SVGElement
{

protected:
    /// @private
    SVG *svg;
    /// @private
    int x;
    /// @private
    int y;
    /// @private
    int id;
    /// @private
    int alpha;
    /// @private
    void (*clickHandler)(SVGElement *);
    /// @private 
    map<std::string,std::string> attributes = map<std::string,std::string>();

    friend class SVG;

    void sendAttributes();

public:
    /// @private
    SVGElement();

    /// @private
    SVGElement(SVG *view);

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    SVGElement(const SVGElement &original);
    
    virtual ~SVGElement();

    /**
     * \brief Add the element to an SVG.
     * 
     * If the element already belongs to an SVG, nothing happens.
     * 
     * @param svg The SVG
     */
    virtual void addTo(SVG *svg);

    /**
     * \brief Add the element to the given view.
     * 
     * @param view The View.
     */
    SVGElement &operator=(const SVGElement &original);

    /// @private
    void copy(const SVGElement &original);
    
    /// @private
    /**
     * Create a basic message object.
     * 
     * @param cmd 
     */
    xeus::xjson getMsg(std::string cmd);

    /**
     * \brief Get the ID of the element.
     * 
     * The ID is specific for the \ref SVG view.
     * 
     * @returns The ID.
     */
    int getId();

    /**
     * \brief Get the x-coordinate of the position.
     * 
     * @returns The x-coordinate
     */
    virtual int getX() {
        return this->x;
    }

    /**
     * \brief Get the y-coordinate of the position.
     * 
     * @returns The y-coordinate
     */
    virtual int getY() {
        return this->y;
    }

    /**
     * \brief Move element to target coordinates.
     * 
     * The reference point of the element is moved to the given target coordinates.
     * The relative position of the reference point in the element depend on its type.
     *
     * @param x The target x-coordinate.
     * @param y The target y-coordinate.
     */
    virtual void moveTo(int x, int y) = 0;

    /**
     * \brief Moves the element by the given offset.
     * 
     * @param dx The offset in horizontal direction.
     * @param dy The offset in vertical direction.
     */
    void moveBy(int dx, int dy);

    /**
     * \brief Set an attribute of the element.
     * 
     * The relevant attributes depend on the type of the element.
     * 
     * @param attr The name of the attribute.
     * @param value The value of the attribute.
     */
    void setAttribute(std::string attr, int value);

    /**
     * \brief Set an attribute of the element.
     * 
     * The relevant attributes depend on the type of the element.
     * 
     * @param attr The name of the attribute.
     * @param value The value of the attribute.
     */
    void setAttribute(std::string attr, std::string value);

    /**
     * \brief Rotate the element to the given angle.
     * 
     * The element is rotated clockwise (positive angle) around its reference point.
     *
     * @param angle The absolute angle.
     */
    virtual void rotateTo(int angle);

    /**
     * \brief Rotate the element by the given angle.
     * 
     * The element is rotated clockwise (positive angle) around its reference point.
     *
     * @param angle The angle by which the element is rotated.
     */
    void rotateBy(int angle);

    /**
     * \brief brings the element to the front.
     * 
     * This operation changes the order of the elements in the \ref SVG.
     * The ement it brought to the fron, ie.e it is drawn last.
     */
    void toFront();

    /**
     * \brief Hide the element.
     */
    void hide();

    /**
     * \brief Show the element,
     */
    void show();

    /**
     * \brief Remove element
     */
    void removeFromView();

    /**
     * \brief Set the drawing color.
     * 
     * The color is given as a [CSS color string](https://www.w3schools.com/cssref/css_colors_legal.asp)
     * or by [CSS color name](https://www.w3schools.com/cssref/css_colors.asp).
     * 
     * @param color The color as CSS color string.
     */
    void setColor(string color = "black");

    /**
     * \brief Set the drawing color.
     * 
     * The color is givan as the red, green and blue component (0..255)
     * and the opacity (0.0 .. 1.0) with 0.0 being fiully transparent.
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    void setColor(int red, int green, int blue, float alpha = 1.0);

    /**
     * \brief Set the fill color.
     * 
     * The color is given as a [CSS color string](https://www.w3schools.com/cssref/css_colors_legal.asp)
     * or by [CSS color name](https://www.w3schools.com/cssref/css_colors.asp).
     * 
     * @param color The color as CSS color string.
     */
    void setFill(string color = "transparent");

    /**
     * \brief Set the fill color.
     * 
     * The color is givan as the red, green and blue component (0..255)
     * and the opacity (0.0 .. 1.0) with 0.0 being fiully transparent.
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    void setFill(int red, int green, int blue, float alpha = 1.0);

    /**
     * \brief Set the line width.
     * 
     * The line width is given in pixel.
     * 
     * @param width the line width.
     */
    void setStrokeWidth(int width);

    /**
     * \brief Check if the two objects represent the same SVG Element in the frontend.
     * 
     * @returns true if both represent the same element.
     */
    friend inline bool operator==(const SVGElement &left, const SVGElement &right);

    /**
     * \brief Check if the two objects represent the same SVG Element in the frontend.
     * 
     * @returns false if both represent the same element.
     */
    friend inline bool operator!=(const SVGElement &left, const SVGElement &right);

    /**
     * \brief Set a function that is executed if the element is clicked.
     * 
     * If during a call of SVG::waitForClick the Element is clicked the handler is executed.
     * It receives the clicked element as only argument.
     * 
     * @param handler The function to be called if the Element is clicked.
     */
    void onclick(void (*handler)(SVGElement *));

protected:
    /// @private
    /**
     * This method is called if the element is clicked.
     */
    virtual void clicked();

    /// @private
    virtual void create();

}; // end of class SVGElement





/**
 * \class SVG SVG.hpp algoviz/AlgoViz.hpp
 * \brief A view for an SVG image in the AlgoViz sidebar.
 * 
 * The size of the SVG is given in pixels. The size of the viewport,
 * ie. its frame in the sidebar, is given in grid rows and columns.
 */
class SVG : public AlgoVizView
{

public:
    /// @private
    int nextElementID = 0;
    /// @private
    map<int, SVGElement*> elements = map<int, SVGElement*>();
    /// @private
    SVGElement *clickedElement = nullptr;

    /// @private
    int width;
    /// @private
    int height;
    /// @private
    string stroke = "black";
    /// @private
    int strokeWidth = 1;
    /// @private
    string fill = "transparent";
    /// @private
    string transform = "";

    friend class SVGElement;

    /**
     * \brief create an SVG in the sidebar.
     * 
     * @param width The width of the SVG in pixels.
     * @param height The height of the SVG in pixels.
     * @param gWidth The width of the frame containing the SVG (in grid spaces).
     * @param gHeight The width of the frame containing the SVG (in grid spaces).
     * @param title The title of the view.
     */
    SVG(int width, int height, int gWidth, int gHeight, std::string title = "SVG")
    {
        this->id = AlgoVizView::nextViewID;
        AlgoVizView::views[this->id] = this;
        AlgoVizView::nextViewID++;

        this->type = "svg";
        this->width = width;
        this->height = height;

        auto msg = xeus::xjson::object();
        msg["type"] = "svg";
        msg["cmd"] = "create";
        msg["width"] = width;
        msg["height"] = height;
        msg["title"] = title;

        if (gWidth <= 0)
        {
            gWidth = width / this->colWidth + (width % this->colWidth > 0 ? 1 : 0);
        }

        if (gHeight <= 0)
        {
            gHeight = (height + 20) / this->rowHeight + ((height + 20) % this->rowHeight > 0 ? 1 : 0);
        }

        AlgoViz::show();

        msg["gwidth"] = gWidth;
        msg["gheight"] = gHeight;
        msg["id"] = this->id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief create an SVG in the sidebar.
     * 
     * @param width The width of the SVG in pixels.
     * @param height The height of the SVG in pixels.
     * @param title The title of the view.
     */
    SVG(int width, int height, std::string title = "SVG") : SVG(width,height,0,0,title) 
    {
    }



    SVG(std::string url, int width, int height, int gw, int gh, std::string title = "SVG") :SVG(width,height,gw,gh,title)
    {
        this->load(url);
    }


    /**
     * \brief Get the width in pixel.
     */
    inline int getWidth()
    {
        return this->width;
    }

    /**
     * \brief Get the height in pixel.
     */
    inline int getHeight()
    {
        return this->height;
    }

    /**
     * \brief Set the ViewBox of the SVG.
     * 
     * The ViewBox is the local coordinate system in which the SVG elements are positioned.
     * It is scled to the actual size of the SVG. Hence, the ViewBox can be used to scale
     * the content.
     * 
     * @param x The x-coordinate of the upper left corner.
     * @param y The y-coordinate of the upper left corner.
     * @param w The width of the local coordinate system.
     * @param h The height of the local coordinat system.
     */
    void setViewBox(int x, int y, int w, int h)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "viewbox";
        obj["id"] = this->id;
        obj["coords"] = std::to_string(x) + " " + std::to_string(y) + " " + std::to_string(w) + " " + std::to_string(h);
        AlgoViz::sendMsg(obj);
    }

    /**
     * @name Basic drawing operations.
     * 
     * This are some operations for drawing to the SVG.
     * 
     * The drawing cannot be manipulated afterwards.
     */
    ///@{

    /**
     * \brief Clear the SVG.
     */
    void clear()
    {
        AlgoVizView::clear();
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "clear";
        obj["id"] = this->id;
        AlgoViz::sendMsg(obj);
        this->elements.clear();
        this->nextElementID = 0;
    }


    /**
     * \brief Set the drawing color.
     * 
     * The color is given as a [CSS color string](https://www.w3schools.com/cssref/css_colors_legal.asp)
     * or by [CSS color name](https://www.w3schools.com/cssref/css_colors.asp).
     * 
     * @param color The color as CSS color string.
     */
    void setColor(string color = "black")
    {
        this->stroke = color;
    }

    /**
     * \brief Set the drawing color.
     * 
     * The color is givan as the red, green and blue component (0..255)
     * and the opacity (0.0 .. 1.0) with 0.0 being fiully transparent.
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    void setColor(int red, int green, int blue, float alpha = 1.0)
    {
        this->stroke = "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) + ")";
    }

    /**
     * \brief Set the fill color.
     * 
     * The color is given as a [CSS color string](https://www.w3schools.com/cssref/css_colors_legal.asp)
     * or by [CSS color name](https://www.w3schools.com/cssref/css_colors.asp).
     * 
     * @param color The color as CSS color string.
     */
    void setFill(string color = "transparent")
    {
        this->fill = color;
    }

    /**
     * \brief Set the fill color.
     * 
     * The color is givan as the red, green and blue component (0..255)
     * and the opacity (0.0 .. 1.0) with 0.0 being fiully transparent.
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    void setFill(int red, int green, int blue, float alpha = 1.0)
    {
        this->fill = "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) + ")";
    }

    /**
     * \brief Set the current line width for draing.
     * 
     * @param width The line width in pixels.
     */
    void setLineWidth(int width = 1)
    {
        this->strokeWidth = width;
    }

    /**
     * \brief Set the transformation for drawing.
     * 
     * The transformation is given as a [CSS transformation string](https://www.w3schools.com/css/css3_2dtransforms.asp).
     * 
     * @param transform The CSS transformation.
     */
    void setTransform(string transform = "")
    {
        this->transform = transform;
    }

    /**
     * \brief Draw a line.
     * 
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     */
    void drawLine(int x1, int y1, int x2, int y2)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "line";
        obj["attrs"] = {"x1", "y1", "x2", "y2", "stroke", "stroke-width", "transform"};
        obj["values"] = {x1, y1, x2, y2, this->stroke, this->strokeWidth, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw a circle.
     * 
     * @param cx The x-coordinate of the center.
     * @param cy The y-coordinate of the center.
     * @param r The radius of the circle.
     */
    void drawCircle(int cx, int cy, int r)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "circle";
        obj["attrs"] = {"cx", "cy", "r", "stroke", "stroke-width", "fill", "transform"};
        obj["values"] = {cx, cy, r, this->stroke, this->strokeWidth, this->fill, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw a rectangle.
     * 
     * @param x The x-coordinate of the upper left corner.
     * @param y The y-coordinate of the upper left corner.
     * @param width The width of the rectangle.
     * @param height The height of the rectangle.
     * @param rx The radius in x-direction of the rounded corners (defaults to 0).
     * @param ry The radius in y-direction of the rounded corners (defaults to 0).
     */
    void drawRect(int x, int y, int width, int height, int rx = 0, int ry = 0)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "rect";
        obj["attrs"] = {"x", "y", "width", "height", "rx", "ry", "stroke", "stroke-width", "fill", "transform"};
        obj["values"] = {x, y, width, height, rx, ry, this->stroke, this->strokeWidth, this->fill, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw an ellipse.
     * 
     * @param x The x-coordinate of the center.
     * @param y The y-coordinate of the center.
     * @param rx The radius in x-direction.
     * @param ry The radius in y-direction.
     */
    void drawEllipse(int cx, int cy, int rx, int ry)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "ellipse";
        obj["attrs"] = {"cx", "cy", "rx", "ry", "stroke", "stroke-width", "fill", "transform"};
        obj["values"] = {cx, cy, rx, ry, this->stroke, this->strokeWidth, this->fill, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw a path.
     *
     * The path is described by a [SVG path string](https://www.w3schools.com/graphics/svg_path.asp)
     * @param d The path as SVG path.
     */
    void drawPath(const string &d)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "path";
        obj["attrs"] = {"d", "stroke", "stroke-width", "fill", "transform"};
        obj["values"] = {d, this->stroke, this->strokeWidth, this->fill, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw a text.
     * 
     * @param text The text to be drawn.
     * @param x The x-coordinate of the left text border.
     * @param y The y-coordinate of the baseline of the text.
     * @param fontSize The size of the font in pixels.
     * @param fontFamily The font family used.
     */
    void drawText(const string &text, int x, int y, int fontSize = 16, const string &fontFamily = "sans-serif")
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "text";
        obj["content"] = text;
        obj["attrs"] = {"x", "y", "font-size", "font-family", "stroke", "stroke-width", "fill", "transform"};
        obj["values"] = {x, y, fontSize, fontFamily, this->stroke, this->strokeWidth, this->fill, this->transform};
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Draw an image.
     * 
     * @param href The file containing the image.
     * @param x The x-coordinate of the upper left corner.
     * @param y The y-coordinate of the upoper left corner.
     * @param width The width of the image.
     * @param height The height of the image.
     */
    void drawImage(const string &href, int x, int y, int width, int height)
    {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        obj["form"] = "image";
        obj["attrs"] = {"href", "x", "y", "width", "height", "transform"};
        obj["values"] = {href, x, y, width, height, this->transform};
        AlgoViz::sendMsg(obj);
    }

    ///@}

    /**
     * \brief Add an element described by a JSON object.
     * 
     * @param obj The JSON object
     */
    void add(xeus::xjson &obj)
    {
        obj["type"] = "svg";
        obj["cmd"] = "add";
        obj["id"] = this->id;
        obj["eid"] = -1;
        AlgoViz::sendMsg(obj);
    }

    /// @private
     /**
     * \brief Add an elem ent to the view.
     * 
     * Does nothing if the element is already assigned to a view.
     * 
     * @param element The element.
     */
    int addElement(SVGElement *element)
    {
        if ( element->svg != nullptr ) return -2;
        this->elements[this->nextElementID] = element;
        return this->nextElementID++;
    }

    /// @private
    inline SVGElement *getElement(int id)
    {
        return this->elements[id];
    }

    /**
     * \brief Get the last element that was clicked.
     * 
     * @returns The pointer to the element.
     */
    inline SVGElement *getClickedElement()
    {
        return this->clickedElement;
    }

    /// @private
    void clicked(const xeus::xjson &obj)
    {
        this->clickedElement = this->elements[id];
        if (this->clickedElement != nullptr)
        {
            this->clickedElement->clicked();
        }
    }

    /**
     * \brief Replace the content of the SVG by a loaded SVG-image.
     * 
     * @param url The URL of the image to be loaded.
     */
    void load(std::string url) {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "load";
        obj["url"] = url;
        obj["id"] = this->id;
        AlgoViz::sendMsg(obj);
    }

    /**
     * \brief Get a vector containing the ids of all elements (with an id).
     * 
     * @returns A vector containing all IDs of elements in this SVG.
     */
    std::vector<std::string> getIDs()
    {
        std::string result = xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#GETIDS", false);
        xeus::xjson obj = xeus::xjson::parse(result);
        return obj["ids"];
    }


    /**
     * \brief Set an attribute of an element in this SVG.
     * 
     * The element is identified by its ID.
     * 
     * The attribute can be given either as JavaScript style attribute or as HTML attribute.
     * I.e. the width of the stroke can be set as "stroke-width" or "strokeWidth".
     * 
     * @param id The ID of the element.
     */
    void setAttribute(std::string id, std::string attr, std::string value) {
        auto obj = xeus::xjson::object();
        obj["type"] = "svg";
        obj["cmd"] = "idattr";
        obj["id"] = this->id;
        obj["eid"] = id;
        obj["attr"] = attr;
        obj["value"] = value;
        AlgoViz::sendMsg(obj);
    }

}; // end of class SVG


// ============================================================================================


/********************************
 *                              *
 * Implementation of SVGElement *
 *                              *
 ********************************/

SVGElement::SVGElement() 
{
    this->svg = nullptr;
    this->id = -1;
}


SVGElement::SVGElement(SVG *view)
{
    this->svg = nullptr;
    this->id = view->addElement(this);
    this->svg = view;
}

SVGElement::SVGElement(const SVGElement &original)
{
    this->svg = nullptr;
    this->copy(original);
}

SVGElement::~SVGElement()  {
    this->svg = nullptr;
    this->id = -1;
}


void SVGElement::addTo(SVG *svg) {
    if ( this->svg != nullptr ) return;
    this->id = svg->addElement(this);
    this->svg = svg;

    this->create();
}


void SVGElement::create() {}


SVGElement &SVGElement::operator=(const SVGElement &original)
{
    this->copy(original);
    return *this;
}

void SVGElement::copy(const SVGElement &original)
{
    this->x = original.x;
    this->y = original.y;
    this->alpha = original.alpha;
    this->id = original.svg->addElement(this);
    this->svg = original.svg;
}

xeus::xjson SVGElement::getMsg(std::string cmd)
{
    auto obj = xeus::xjson::object();

    if ( this->svg != nullptr ) {
        obj["type"] = "svg";
        obj["cmd"] = cmd;
        obj["id"] = this->svg->getId();
        obj["eid"] = this->id;
    } else {
        obj["type"] = "#IGNORE";
    }

    return obj;
}

int SVGElement::getId()
{
    return this->id;
}

void SVGElement::moveBy(int dx, int dy)
{
    this->moveTo(this->x + dx, this->y + dy);
}


void SVGElement::sendAttributes() {
    auto msg = this->getMsg("attrs");
    list<string> a;
    list<string> v;
    for ( auto attr : this->attributes ) {        
        a.push_back(attr.first);
        v.push_back(attr.second);
    }
    msg["attrs"] = a;
    msg["values"] = v;
    AlgoViz::sendMsg(msg);
 }


void SVGElement::setAttribute(const std::string attr, int value)
{
    this->attributes[attr] = to_string(value);
    auto msg = this->getMsg("attrs");
    msg["attrs"] = { attr };
    msg["values"] = { value };
    AlgoViz::sendMsg(msg);
}

void SVGElement::setAttribute(std::string attr, std::string value)
{
    this->attributes[attr] = value;
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {attr};
    msg["values"] = {value};
    AlgoViz::sendMsg(msg);
}

void SVGElement::rotateTo(int angle)
{
    this->alpha = angle;
    auto msg = this->getMsg("rotate");
    msg["angle"] = angle;
    AlgoViz::sendMsg(msg);
}

void SVGElement::rotateBy(int angle)
{
    this->rotateTo(this->alpha += angle);
}

void SVGElement::toFront()
{
    auto msg = this->getMsg("tofront");
    AlgoViz::sendMsg(msg);
}

void SVGElement::hide()
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"display"};
    msg["values"] = {"none"};
    AlgoViz::sendMsg(msg);
}

void SVGElement::show()
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"display"};
    msg["values"] = {""};
    AlgoViz::sendMsg(msg);
}

void SVGElement::removeFromView()
{
    auto msg = this->getMsg("remove");
    AlgoViz::sendMsg(msg);
}

void SVGElement::setColor(string color)
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"stroke"};
    msg["values"] = {color};
    this->attributes["stroke"] = color;
    AlgoViz::sendMsg(msg);
}

void SVGElement::setColor(int red, int green, int blue, float alpha)
{

    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"stroke"};
    string color = "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) + ")";
    msg["values"] = {color};
    this->attributes["stroke"] = color;
    AlgoViz::sendMsg(msg);
}

void SVGElement::setFill(string color)
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"fill"};
    msg["values"] = {color};
    this->attributes["fill"] = color;
    AlgoViz::sendMsg(msg);
}

void SVGElement::setFill(int red, int green, int blue, float alpha)
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"fill"};
    string color = "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) + ")";
    this->attributes["fill"] = color;
    msg["values"] = {color};
    AlgoViz::sendMsg(msg);
}

void SVGElement::setStrokeWidth(int width)
{
    auto msg = this->getMsg("attrs");
    msg["attrs"] = {"stroke-width"};
    msg["values"] = {width};
    this->attributes["stroke-width"] = to_string(width);
    AlgoViz::sendMsg(msg);
}

inline bool operator==(const SVGElement &left, const SVGElement &right)
{
    return ((left.id == right.id) && (left.svg == right.svg));
}

inline bool operator!=(const SVGElement &left, const SVGElement &right)
{
    return ((left.id != right.id) || (left.svg != right.svg));
}

void SVGElement::clicked()
{
    if (this->clickHandler != nullptr)
    {
        this->clickHandler(this);
    }
}

void SVGElement::onclick(void (*handler)(SVGElement *))
{
    this->clickHandler = handler;
}




/*****************************************
 *                                       *
 * Implementation of several SVGElements *
 *                                       *
 *****************************************/

//===============================================================================

/**
 * \class Circle Circle.hpp algoviz/AlgoViz.hpp
 * \brief A circle
 * 
 * This code creates an \ref SVG and adds a circle:
 * 
 *     SVG view = SVG(200,200,4,4);
 *     Circle c = Circle(50,50,20,&view);
 * 
 * Relevant attributes for a circle are:
 * * "r" - its radius (int)
 * * "cx" - the x-coordiante of its center (int)
 * * "cy" - the y-coordiante of its center (int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 * 
 * The following code set the circle's bounding to a 5px wide red line. 
 * 
 *     c.setAttribute("stroke","#FF0000");
 *     c.setAttribute("stroke-width", 5);
 */
class Circle : public SVGElement
{

protected:
    /// @private
    int radius;

public:

    /// @private
    Circle() : SVGElement() {};

    /**
     * \brief Add a circle to the \ref SVG.
     * 
     * @param cx The x-coordinate of the circle's center.
     * @param cy The y-coordinate of the circle's center.
     * @param radius The circle's radius.
     * @param view A pointer to the \ref SVG view.
     */
    Circle(int cx, int cy, int radius, SVG *view) : SVGElement(view)
    {
        this->x = cx;
        this->y = cy;
        this->radius = radius;

        this->create();
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Circle(const Circle &original)
    {
        this->copy(original);
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Circle &operator=(const Circle &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "circle";
        msg["attrs"] = {"cx", "cy", "r"};
        msg["values"] = {this->x, this->y, this->radius};
        AlgoViz::sendMsg(msg);
    }


    /// @private
    /**
     * \brief Copy constructor
     * 
     * Create a new copy of the circle.
     * 
     * @param original  The origianl circle.
     */
    void copy(const Circle &original)
    { // Circle(const Circle& original) : SVGElement(original) {
        SVGElement::copy(original);
        this->radius = original.radius;

        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Move the circle to target coordinates.
     * 
     * The center of the circle is moved to the given target coordinates.
     *
     * @param x The target x-coordinate.
     * @param y The target y-coordinate.
     */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"cx", "cy"};
        msg["values"] = {this->x, this->y};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Set the circle's radius.
     * 
     * Negative values are ignored.
     * 
     * @param radius The new radius.
     */
    void setRadius(int radius)
    {
        if (radius < 0)
            return;
        this->radius = radius;
        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"r"};
        msg["values"] = {radius};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Get the radius of the circle.
     * 
     * @returns The radius.
     */
    inline int getRadius() { return this->radius; }
};


//===============================================================================

/**
 * \class Line Line.hpp algoviz/AlgoViz.hpp
 * \brief A line
 * 
 * This code creates an \ref SVG and adds a line:
 * 
 *     SVG view = SVG(200,200,4,4);
 *     Line l = Line(50,50,100,150,,&view);
 * 
 * Relevant attributes for a line are:
 * * "x1" and "y1" - the coordiantes of its first endpoint (int)
 * * "x2" and "y2" - the coordiantes of its sencond endpoint (int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 * 
 * The following code set the line to 5 pixel width and paints it green.
 * 
 *     l.setAttribute("stroke","#00FF00");
 *     l.setAttribute("stroke-width", 5);
 */
class Line : public SVGElement
{

protected:
    /// @private
    int x2;
    /// @private
    int y2;

public:

    /// @private
    Line() : SVGElement() {};

    /**
         * \brief Add a line  to the \ref SVG.
         * 
         * @param x1 The x-coordinate of the line's first endpoint.
         * @param y1 The y-coordinate of the line's first endpoint.
         * @param x2 The x-coordinate of the line's second endpoint.
         * @param y2 The y-coordinate of the line's second endpoint.
         * @param view A pointer to the \ref SVG view.
         */
    Line(int x1, int y1, int x2, int y2, SVG *view) : SVGElement(view)
    {
        this->x = x1;
        this->y = y1;
        this->x2 = x2;
        this->y2 = y2;

        this->create();
    }   

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Line(const Line &original)
    {
        this->copy(original);
    }

    /// @private
    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "line";
        msg["attrs"] = {"x1", "y1", "x2", "y2"};
        msg["values"] = {this->x, this->y, this->x2, this->y2};
        AlgoViz::sendMsg(msg);
        this->sendAttributes();
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Line &operator=(const Line &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the line.
     * 
     * @param original  The origianl line.
     */
    void copy(const Line &original)
    {
        SVGElement::copy(original);
        this->x2 = original.x2;
        this->y2 = original.y2;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Move the line to target coordinates.
         * 
         * The first endpoint of the line is moved to the given target coordinates.
         * The position of the second endpoint relative to the first is not changed.
         *
         * @param x The target x-coordinate.
         * @param y The target y-coordinate.
         */
    void moveTo(int x, int y)
    {
        this->x2 = x + (this->x2 - this->x);
        this->y2 = y + (this->y2 - this->y);
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"x1", "y1", "x2", "y2"};
        msg["values"] = {this->x, this->y, this->x2, this->y2};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Get the x-coordinate of the second point.
     * 
     * @returns The x-coordinate.
     */
    inline int getX2() { return this->x2; }


    /**
     * \brief Get the y-coordinate of the second point.
     * 
     * @returns The y-coordinate.
     */
    inline int getY2() { return this->y2; }

};


//===============================================================================


/**
 * \class Rect Rect.hpp algoviz/AlgoViz.hpp
 * \brief A rectangle
 * 
 * This code creates an \ref SVG and adds a rectangle:
 * 
 *     SVG view = SVG(200,200,4,4);
 *     Rectangle r = Rectangle(50,50,100,150,&view);
 * 
 * Relevant attributes for a line are:
 * * "x" and "y" - the coordiantes of the rectangle's upper left corner. (int)
 * * "width" and "height" - the rectangle's size (int)
 * * "rx" and "ry" - the radiuses of the rectangle's corners (int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 * 
 * The following code sets the corners radius in both directions to 5 pixel.
 * 
 *     r.setAttribute("rx",5);
 *     r.setAttribute("ry",5);
 */
class Rect : public SVGElement
{

protected:
    /// @private
    int w;
    /// @private
    int h;
    /// @private
    int rx;
    /// @private
    int ry;

public:
    /// @private
    Rect() : SVGElement() {};

    /**
         * \brief Add a rectangle to the \ref SVG.
         * 
         * @param x The x-coordinate of the upper left corner.
         * @param y The y-coordinate of the upper left corner.
         * @param w The width.
         * @param h The height.
         * @param rx The horizontal corner radius
         * @param ry The vertical corner radius
         * @param view A pointer to the \ref SVG view.
         */
    Rect(int x, int y, int w, int h, int rx, int ry, SVG *view) : SVGElement(view)
    {
        this->x = x;
        this->y = y;
        this->w = w;
        this->h = h;
        this->rx = 0;
        this->ry = 0;

        this->create();
    }

    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "rect";
        msg["attrs"] = {"x", "y", "width", "height", "rx", "ry"};
        msg["values"] = {this->x, this->y, this->w, this->h, this->rx, this->ry};
        AlgoViz::sendMsg(msg);
        this->sendAttributes();
    }

    /**
         * \brief Add a rectangle to the \ref SVG.
         * 
         * @param x The x-coordinate of the upper left corner.
         * @param y The y-coordinate of the upper left corner.
         * @param w The width.
         * @param h The height.
         * @param view A pointer to the \ref SVG view.
         */
    Rect(int x, int y, int w, int h, SVG *view) : Rect(x, y, w, h, 0, 0, view) {}

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Rect(const Rect &original)
    {
        this->copy(original);
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Rect &operator=(const Rect &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Rect.
     */
    void copy(const Rect &original)
    {
        SVGElement::copy(original);
        this->w = original.w;
        this->h = original.h;
        this->rx = original.rx;
        this->ry = original.ry;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Move the rectangle to target coordinates.
         * 
         * The upper left corner of the rectangle is moved to the given target coordinates.
         *
         * @param x The target x-coordinate.
         * @param y The target y-coordinate.
         */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"x", "y"};
        msg["values"] = {this->x, this->y};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Set the rectangles width.
     * 
     * @param w The new width.
     */
    void setWidth(int w)
    {
        this->w = w;
        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"width"};
        msg["values"] = {this->w};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Set the rectangles height.
     * 
     * @param h The new height.
     */
    void setHeight(int h)
    {
        this->h = h;
        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"height"};
        msg["values"] = {this->h};
        AlgoViz::sendMsg(msg);
    }


    /**
     * \brief Get the width of the rectangle.
     * 
     * @returns The width.
     */
    inline int getWidth() { return this->w; }


    /**
     * \brief Get the height of the rectangle.
     * 
     * @returns The height.
     */
    inline int getHeight() { return this->h; }

};


//===============================================================================


/**
 * \class Ellipse Ellipse.hpp algoviz/AlgoViz.hpp
 * \brief An ellipse
 * 
 * This code creates an \ref SVG and adds an ellipse:
 * 
 *     SVG view = SVG(200,200,4,4);
 *     Ellipse e = Ellipse(50,50,20,30,&view);
 * 
 * Relevant attributes for a circle are:
 * * "cx" and "cy" - the coordiantes of its center (int)
 * * "rx" and "ry"- the radiuses(int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 * 
 * The following code set the ellipse's bounding to a 5px wide red line. 
 * 
 *     e.setAttribute("stroke","#FF0000");
 *     e.setAttribute("stroke-width", 5);
 */
class Ellipse : public SVGElement
{

protected:
    /// @private
    int rx;
    /// @private
    int ry;

public:

    /// @private
    Ellipse() : SVGElement() {};

    /**
         * \brief Add a circle to the \ref SVG.
         * 
         * @param cx The x-coordinate of the circle's center.
         * @param cy The y-coordinate of the circle's center.
         * @param rx The circle's horizontal radius.
         * @param ry The circle's vertical radius.
         * @param view A pointer to the \ref SVG view.
         */
    Ellipse(int cx, int cy, int rx, int ry, SVG *view) : SVGElement(view)
    {
        this->x = cx;
        this->y = cy;
        this->rx = rx;
        this->ry = ry;

        this->create();
    }


    void create() {        
        auto msg = this->getMsg("add");
        msg["form"] = "ellipse";
        msg["attrs"] = {"cx", "cy", "rx", "ry"};
        msg["values"] = {this->x, this->y, this->rx, this->ry};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Ellipse(const Ellipse &original)
    {
        this->copy(original);
    }

    /**
     * \brief Assignment operator.
     */
    /// @private
    Ellipse &operator=(const Ellipse &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Ellipse.
     */
    void copy(const Ellipse &original)
    {
        SVGElement::copy(original);
        this->rx = original.rx;
        this->ry = original.ry;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Move the ellipse to target coordinates.
         * 
         * The center of the ellipse is moved to the given target coordinates.
         *
         * @param x The target x-coordinate.
         * @param y The target y-coordinate.
         */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"cx", "cy"};
        msg["values"] = {this->x, this->y};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Set the both radii of the ellipse.
     * 
     * @param rx The horizontal radius.
     * @param ry The vertical radius.
     */
    void setRadii(int rx, int ry)
    {
        this->rx = rx;
        this->ry = ry;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"rx", "ry"};
        msg["values"] = {this->rx, this->ry};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Get the horizontal radius.
     * 
     * @returns The horizontal radius.
     */
    inline int getRadiusX() { return this->rx; }


    /**
     * \brief Get the vertical radius.
     * 
     * @returns The vertical radius.
     */
    inline int getRadiusY() { return this->ry; }

};


//===============================================================================


/**
 * \class Text Text.hpp algoviz/AlgoViz.hpp
 * \brief A text
 * 
 * This code creates an \ref SVG and adds a text:
 * 
 *     SVG view = SVG(200,200,4,4);
 *     Text t = Text("Allons-y!",50,50,&view);
 * 
 * Relevant attributes for a circle are:
 * * "x" and "y" - the coordiantes of its center (int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 * 
 * The following code set the ellipse's bounding to a 5px wide red line. 
 * 
 *     e.setAttribute("stroke","#FF0000");
 *     e.setAttribute("stroke-width", 5);
 */
class Text : public SVGElement
{

protected:
    /// @private
    std::string content;

public:

    /// @private
    Text() : SVGElement() {};

    /**
         * \brief Add a text to the \ref SVG.
         * 
         * @param text The text to be displayed.
         * @param x The x-coordinate of the circle's center.
         * @param y The y-coordinate of the circle's center.
         * @param view A pointer to the \ref SVG view.
         */
    Text(std::string text, int x, int y, SVG *view) : SVGElement(view)
    {
        this->x = x;
        this->y = y;
        this->content = text;

        this->create();
    }


    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "text";
        msg["attrs"] = {"x", "y"};
        msg["values"] = {this->x, this->y};
        msg["content"] = this->content;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Text(const Text &original)
    {
        this->copy(original);
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Text &operator=(const Text &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Text.
     */
    void copy(const Text &original)
    {
        SVGElement::copy(original);
        this->content = original.content;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Move the text to target coordinates.
         * 
         * @param x The target x-coordinate.
         * @param y The target y-coordinate.
         */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"x", "y"};
        msg["values"] = {this->x, this->y};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Change the displayed text
     * 
     * @param text the text
     */
    void setText(std::string text)
    {
        this->content = text;

        auto msg = this->getMsg("settext");
        msg["content"] = this->content;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Get the text.
     * 
     * @returns The text.
     */
    inline std::string getText() { return this->content; }

};


//===============================================================================


/**
 * \class Path Path.hpp algoviz/AlgoViz.hpp
 * \brief An SVG-path
 *
 * The path is given as a string of path commands.
 * A detailed description can be found in the
 * [MDN web docs](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/Paths)
 * 
 * Relevant attributes for a circle are:
 * * "x" and "y" - the coordiantes of its center (int)
 * * "stroke" - the color of its bounding line (color)
 * * "stroke-width" - the width of the bounding line (int)
 * * "fill" - the color of the circle (color)
 */
class Path : public SVGElement
{

protected:
    /// @private
    std::string d;

public:

    /// @private
    Path() : SVGElement() {};

    /**
         * \brief Add a path to the \ref SVG.
         * 
         * @param path The path as a sequence of SVG-path commands.
         * @param view A pointer to the \ref SVG view.
         */
    Path(std::string path, SVG *view) : SVGElement(view)
    {
        this->d = path;
        this->create();
    }


    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "path";
        msg["attrs"] = {"d", "fill"};
        msg["values"] = {this->d, "transparent"};
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Path(const Path &original)
    {
        this->copy(original);
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Path &operator=(const Path &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Path.
     */
    void copy(const Path &original)
    {
        SVGElement::copy(original);
        this->d = original.d;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Move the path to target coordinates.
     * 
     * The center of the path is moved to the target coordinates.
     * 
     * @param x The target x-coordinate.
     * @param y The target y-coordinate.
     */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("transform");
        msg["x"] = this->x;
        msg["y"] = this->y;
        msg["angle"] = this->alpha;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Rotate the path around it's center.
     * 
     * @param alpha The angle in degree.
     */
    void rotateTo(int alpha)
    {
        this->alpha = alpha;

        auto msg = this->getMsg("transform");
        msg["x"] = this->x;
        msg["y"] = this->y;
        msg["angle"] = this->alpha;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Change the path.
         * 
         * @param path The new path.
         */
    void setPath(std::string path)
    {
        this->d = path;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"d"};
        msg["values"] = {this->d};
        AlgoViz::sendMsg(msg);
    }
};


//===============================================================================


/**
 * \class Group Group.hpp algoviz/AlgoViz.hpp
 * \brief A group of \ref SVGElement
 *
 * Objects of the class \ref SVGElement can be organized in groups.
 * These can be moved, rotated and placed together.
 */
class Group : public SVGElement
{

public:

    /// @private
    Group() : SVGElement() {};

    /**
         * \brief Add a group to the \ref SVG.
         * 
         * @param view A pointer to the \ref SVG view.
         */
    Group(SVG *view) : SVGElement(view)
    {
        this->x = 0;
        this->y = 0;
        this->create();
    }


    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "g";
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Group(const Group &original)
    {
        this->copy(original);
    }

    /// @private
    /**
     * \brief Assignment operator.
     */
    Group &operator=(const Group &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Group.
     */
    void copy(const Group &original)
    {
        SVGElement::copy(original);
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Move the group to the target coordinates.
         * 
         * @param x The target x-coordinate.
         * @param y The target y-coordinate.
         */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"transform"};
        msg["values"] = {"translate(" + std::to_string(this->x) + "," + std::to_string(this->y) + ")"};
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Add an anonymous SVG element the group.
         * 
         * @param element The element to be added.
         */
    void add(xeus::xjson obj)
    {
        obj["type"] = "svg";
        obj["cmd"] = "addChild";
        obj["id"] = svg->getId();
        obj["eid"] = this->id;
        obj["childid"] = -1;
        AlgoViz::sendMsg(obj);
    }

    /**
         * \brief Add an \ref SVGElement to the group.
         * 
         * @param element The element to be added.
         */
    void add(SVGElement *element)
    {
        auto msg = this->getMsg("addChild");
        msg["childid"] = element->getId();
        msg["eid"] = this->id;        
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief remove an \ref SVGElement from the group.
         * 
         * @param element The element to be removed.
         */
    void remove(SVGElement *element)
    {
        auto msg = this->getMsg("removeChild");
        msg["childid"] = element->getId();
        AlgoViz::sendMsg(msg);
    }

    /**
         * \brief Remove all children from group.
         */
    void clear()
    {
        auto msg = this->getMsg("empty");
        AlgoViz::sendMsg(msg);
    }
};


//===============================================================================


/**
 * \class Image Image.hpp algoviz/AlgoViz.hpp
 * \brief An image
 * 
 * This object represents an image in an SVG view. It is given by the
 * filename, ralative to the notebook path.
 */
class Image : public SVGElement
{

protected:
    /// @private
    int w;
    /// @private
    int h;
    /// @private
    std::string path;

public:

    /// @private
    Image() : SVGElement() {};

    /**
         * \brief Add an image to the \ref SVG.
         * 
         * @param path The path to the file.
         * @param x The x-coordinate of the upper left corner.
         * @param y The y-coordinate of the upper left corner.
         * @param w The width.
         * @param h The height.
         * @param view A pointer to the \ref SVG view.
         */
    Image(const std::string path, int x, int y, int w, int h, SVG *view) : SVGElement(view)
    {
        this->x = x;
        this->y = y;
        this->w = w;
        this->h = h;
        this->path = path;
        this->create();
    }


    void create() {
        auto msg = this->getMsg("add");
        msg["form"] = "image";
        msg["attrs"] = {"width", "height", "href"};

        if ((path[0] != '/'))
        {
            msg["values"] = {this->w, this->h, path};
        }
        else
        {
            msg["values"] = {this->w, this->h, path};
        }
        AlgoViz::sendMsg(msg);

        this->moveTo(this->x, this->y);
    }

    /**
     * \brief Copy constructor
     * 
     * This constructor creates a new SVGElement in the same view.
     */
    Image(const Image &original)
    {
        this->copy(original);
    }
    
    /// @private
    /**
     * \brief Assignment operator.
     */
    Image &operator=(const Image &original)
    {
        this->copy(original);
        return *this;
    }

    /// @private
    /**
     * \brief Copy Line
     * 
     * Create a new copy of the Line.
     * 
     * @param original  The origianl Image.
     */
    void copy(const Image &original)
    {
        SVGElement::copy(original);
        this->w = original.w;
        this->h = original.h;
        this->path = original.path;
        auto msg = this->getMsg("clone");
        msg["original"] = original.id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Move the image to target coordinates.
     * 
     * The upper left corner of the image is moved to the given target coordinates.
     *
     * @param x The target x-coordinate.
     * @param y The target y-coordinate.
     */
    void moveTo(int x, int y)
    {
        this->x = x;
        this->y = y;

        auto msg = this->getMsg("transform");
        msg["x"] = this->x;
        msg["y"] = this->y;
        msg["angle"] = this->alpha;
        AlgoViz::sendMsg(msg);
    }

    void rotateTo(int alpha)
    {
        this->alpha = alpha;

        auto msg = this->getMsg("transform");
        msg["x"] = this->x;
        msg["y"] = this->y;
        msg["angle"] = this->alpha;
        AlgoViz::sendMsg(msg);
    }

    /**
     * \brief Set the size of the image.
     * 
     * @param w The width.
     * @param h The height.
     */
    void setSize(int w, int h)
    {
        this->w = w;
        this->h = h;

        auto msg = this->getMsg("attrs");
        msg["attrs"] = {"width", "height"};
        msg["values"] = {this->w, this->h};
        AlgoViz::sendMsg(msg);
    }
};

///@{

#endif