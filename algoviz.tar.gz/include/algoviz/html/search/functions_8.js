var searchData=
[
  ['image_149',['Image',['../classImage.html#a90dbe262842406972c2d1f6bbbb64e53',1,'Image::Image(const std::string path, int x, int y, int w, int h, SVG *view)'],['../classImage.html#ab31fc0553901570d8b3bb550c5b61fd8',1,'Image::Image(const Image &amp;original)']]],
  ['init_150',['init',['../classTurtle.html#a3c5a8cc7cc5a16b3ffb2be0c24eda79c',1,'Turtle']]],
  ['isleaf_151',['isLeaf',['../classBinTree.html#aa256918b8d03a8de1a9b61e0726600b8',1,'BinTree']]],
  ['isroot_152',['isRoot',['../classBinTree.html#a4e1320268203d115e43e244f64981170',1,'BinTree']]]
];
