var searchData=
[
  ['ellipse_24',['Ellipse',['../classEllipse.html',1,'Ellipse'],['../classEllipse.html#a50b896affe659547ca23586df944b4c0',1,'Ellipse::Ellipse(int cx, int cy, int rx, int ry, SVG *view)'],['../classEllipse.html#af4e08e91e9d321e9a6008feb1914bac0',1,'Ellipse::Ellipse(const Ellipse &amp;original)']]]
];
