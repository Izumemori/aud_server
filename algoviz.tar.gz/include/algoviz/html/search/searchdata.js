var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstu",
  1: "abceghilnprst",
  2: "abcdefghilmnoprstu",
  3: "o",
  4: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Friends",
  4: "Pages"
};

