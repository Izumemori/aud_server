var searchData=
[
  ['moveby_156',['moveBy',['../classSVGElement.html#acb7557d79fabc34fa62eb7504c419547',1,'SVGElement']]],
  ['moveto_157',['moveTo',['../classSVGElement.html#acde9d253c3cd77faea8ebb70175a45b7',1,'SVGElement::moveTo()'],['../classCircle.html#a7454c49983038ccce6309cb195dbba00',1,'Circle::moveTo()'],['../classLine.html#a6e4c3ddfba235d5226ca5e2ed30cc0d3',1,'Line::moveTo()'],['../classRect.html#a63998b51995deb56076f04035c0bb22a',1,'Rect::moveTo()'],['../classEllipse.html#a9b3e956b9a71da2cbe76cd3eed60e888',1,'Ellipse::moveTo()'],['../classText.html#abe7c2cc06a6aba6e0d82f44243803eb7',1,'Text::moveTo()'],['../classPath.html#aed4ee1ac2e6812e02b30158e0e5ec4f7',1,'Path::moveTo()'],['../classGroup.html#ad72e275ce45d552322872213748956ea',1,'Group::moveTo()'],['../classImage.html#afe07aff40ff6606cba87c733e03a201b',1,'Image::moveTo()'],['../classTurtle.html#a4fe1386a5dab81fea6a5e1f01920d322',1,'Turtle::moveTo()']]]
];
