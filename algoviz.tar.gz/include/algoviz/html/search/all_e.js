var searchData=
[
  ['rect_59',['Rect',['../classRect.html',1,'Rect'],['../classRect.html#a1c03b834506e4a2cc4b74a7f4482edc8',1,'Rect::Rect(int x, int y, int w, int h, int rx, int ry, SVG *view)'],['../classRect.html#aedc2f6d494a2fdec582390ad469d1ad7',1,'Rect::Rect(int x, int y, int w, int h, SVG *view)'],['../classRect.html#a496981794d0410328860ce9b4be79454',1,'Rect::Rect(const Rect &amp;original)']]],
  ['remove_60',['remove',['../classGroup.html#a6e822da0d635064746616f7c2b8b8e74',1,'Group']]],
  ['removefromview_61',['removeFromView',['../classSVGElement.html#ac0c32bcf1533376fc09acf480d601d46',1,'SVGElement']]],
  ['reset_62',['reset',['../classTurtle.html#ae159ce4351bf80f3280830ea8e3dbfc8',1,'Turtle']]],
  ['rotateby_63',['rotateBy',['../classSVGElement.html#aa7a8d591c2c5b23fbee28999098b5f4f',1,'SVGElement']]],
  ['rotateto_64',['rotateTo',['../classSVGElement.html#abcd62f2964be4ff9535a2728e01b46a1',1,'SVGElement::rotateTo()'],['../classTurtle.html#a1c513597225f722a606d34f68f4bffa7',1,'Turtle::rotateTo()']]]
];
