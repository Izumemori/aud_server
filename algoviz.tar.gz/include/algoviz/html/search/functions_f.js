var searchData=
[
  ['sendtext_169',['sendText',['../classAlgoViz.html#a721ead5caee4006df56f5748d6bdcc5f',1,'AlgoViz']]],
  ['set_170',['set',['../classHTML.html#a9dd13d21ae02a4df26754799cbb47c3c',1,'HTML']]],
  ['setattribute_171',['setAttribute',['../classBinTree.html#a99680c15373c614c1876d53154dc39eb',1,'BinTree::setAttribute()'],['../classSVGElement.html#aad45e24b18e9af11e7902e09fa4effc0',1,'SVGElement::setAttribute(std::string attr, int value)'],['../classSVGElement.html#ab52b0d83a1c8efc3afd076535c943007',1,'SVGElement::setAttribute(std::string attr, std::string value)'],['../classHTML.html#ac9384e008d140b11fa6de228d09e255c',1,'HTML::setAttribute(const std::string &amp;name, const std::string &amp;value)'],['../classHTML.html#a4539b4f6581879227eee710778e43c80',1,'HTML::setAttribute(const std::string &amp;name, int value)']]],
  ['setchild_172',['setChild',['../classConnectionView.html#adfa2002c4e9d9493a301fc5a9b15a3f9',1,'ConnectionView']]],
  ['setcolor_173',['setColor',['../classSVG.html#a8ff6824623d9b4e62502cfdcf6f69ad2',1,'SVG::setColor(string color=&quot;black&quot;)'],['../classSVG.html#ab56f4fc5e3d4f26337b534d29408b21a',1,'SVG::setColor(int red, int green, int blue, float alpha=1.0)'],['../classSVGElement.html#a94571bfc82506b1b8fd209fbd6006b81',1,'SVGElement::setColor(string color=&quot;black&quot;)'],['../classSVGElement.html#aec66441d70a2c503fe0bf54eaccec18d',1,'SVGElement::setColor(int red, int green, int blue, float alpha=1.0)'],['../classTurtle.html#a5d0b0af9d993750bac43d6a62771d311',1,'Turtle::setColor()']]],
  ['setfill_174',['setFill',['../classSVG.html#aaeb2072a1f89dcad973968746798c229',1,'SVG::setFill(string color=&quot;transparent&quot;)'],['../classSVG.html#a92637d4c179bc2b8d82d6dcf525914d9',1,'SVG::setFill(int red, int green, int blue, float alpha=1.0)'],['../classSVGElement.html#a6180e293d17ae9e27caa8be6d916928b',1,'SVGElement::setFill(string color=&quot;transparent&quot;)'],['../classSVGElement.html#a367f23575256dc51ac23059595e11b50',1,'SVGElement::setFill(int red, int green, int blue, float alpha=1.0)']]],
  ['setlabel_175',['setLabel',['../classNodeView.html#a961e8f122b72daeabf7b3f2f6443e6be',1,'NodeView::setLabel()'],['../classConnectionView.html#a90a75e2813dd6db69b32ca44d44586d7',1,'ConnectionView::setLabel()']]],
  ['setleftchild_176',['setLeftChild',['../classBinTree.html#a4bddcc8a98b0352502f460b8acfaa25d',1,'BinTree::setLeftChild()'],['../classNodeView.html#afaf7b29884000baf5923055462540214',1,'NodeView::setLeftChild()']]],
  ['setlinewidth_177',['setLineWidth',['../classSVG.html#a67b530ce2445cb02233daa868aa0195a',1,'SVG']]],
  ['setpath_178',['setPath',['../classPath.html#a810abe0ef21f4d04e18213643b8ae0c2',1,'Path']]],
  ['setposition_179',['setPosition',['../classNodeView.html#aeb31f83636cb56332705160d77bdf592',1,'NodeView']]],
  ['setradius_180',['setRadius',['../classCircle.html#a44c925cae1c7fbb29044cb1a9178a283',1,'Circle']]],
  ['setrightchild_181',['setRightChild',['../classBinTree.html#a3141bea7537683d043358b3870ed2908',1,'BinTree::setRightChild()'],['../classNodeView.html#a4d9025421561a96d6edd841e94e49169',1,'NodeView::setRightChild()']]],
  ['setstrokewidth_182',['setStrokeWidth',['../classSVGElement.html#a1fb9e2091ea6d8a58977aa3b8cfc3740',1,'SVGElement']]],
  ['settext_183',['setText',['../classNodeView.html#a5469c9cec2b1f87dd811893e73fd2c39',1,'NodeView::setText()'],['../classText.html#ab2d8c95b3d746ae3e8c0fba8318743c9',1,'Text::setText()']]],
  ['settransform_184',['setTransform',['../classSVG.html#ac4aa837d16308f40303971173a2b7903',1,'SVG']]],
  ['setviewbox_185',['setViewBox',['../classSVG.html#aeb28a9b71f28228fb91a3f9b6b8a0dd8',1,'SVG']]],
  ['setwidth_186',['setWidth',['../classTurtle.html#abaa8125c7e1b2092c363780adcdc69cf',1,'Turtle']]],
  ['show_187',['show',['../classAlgoViz.html#a8e28621d252eb002394b7f6a88cfd067',1,'AlgoViz::show()'],['../classSVGElement.html#adac6cf8a4951268fb3037d965878ed79',1,'SVGElement::show()'],['../classTurtle.html#ab8688cf127bfe1de5c933ff7eac2cb15',1,'Turtle::show()'],['../classAlgoVizView.html#a6858a93666521129f94f17833def5832',1,'AlgoVizView::show()']]],
  ['svg_188',['SVG',['../classSVG.html#a2192dded3d7f02e93d31eeec15904b7b',1,'SVG::SVG(int width, int height, int gWidth, int gHeight)'],['../classSVG.html#ac11f28d97e3aaa2ddb6de475f8a8755f',1,'SVG::SVG(int width, int height)']]],
  ['svgelement_189',['SVGElement',['../classSVGElement.html#aee9447d6b7b4fea792959c2ecf34788d',1,'SVGElement::SVGElement(SVG *view)'],['../classSVGElement.html#a58317697224c714465d3f5e929cdb458',1,'SVGElement::SVGElement(const SVGElement &amp;original)']]]
];
