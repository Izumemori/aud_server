var searchData=
[
  ['text_190',['Text',['../classText.html#a9b60a6dd08360f119bf085e9ef442457',1,'Text::Text(std::string text, int x, int y, SVG *view)'],['../classText.html#a6ed1d213a792ceafd460535b3d9b64c2',1,'Text::Text(const Text &amp;original)']]],
  ['tofront_191',['toFront',['../classSVGElement.html#a0513e58b84c242f41be00d9ce4c3fa4f',1,'SVGElement']]],
  ['turn_192',['turn',['../classTurtle.html#a6cae389026a33e4a66bafa27c59136e9',1,'Turtle']]],
  ['turtle_193',['Turtle',['../classTurtle.html#a55099ab7ace5697c63c1e4ed1812e6a0',1,'Turtle::Turtle(SVG *view)'],['../classTurtle.html#a884f78b463367017087b606f91469161',1,'Turtle::Turtle(int width, int height)']]]
];
