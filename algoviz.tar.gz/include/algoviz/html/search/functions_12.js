var searchData=
[
  ['version_250',['version',['../classAlgoViz.html#a64b74ff9669e6a555c536b4de9f10c9e',1,'AlgoViz']]]
];
