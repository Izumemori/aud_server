var searchData=
[
  ['text_111',['Text',['../classText.html',1,'Text'],['../classText.html#a9b60a6dd08360f119bf085e9ef442457',1,'Text::Text(std::string text, int x, int y, SVG *view)'],['../classText.html#a6ed1d213a792ceafd460535b3d9b64c2',1,'Text::Text(const Text &amp;original)']]],
  ['tofront_112',['toFront',['../classSVGElement.html#a0513e58b84c242f41be00d9ce4c3fa4f',1,'SVGElement']]],
  ['turn_113',['turn',['../classTurtle.html#a6cae389026a33e4a66bafa27c59136e9',1,'Turtle']]],
  ['turtle_114',['Turtle',['../classTurtle.html',1,'Turtle'],['../classTurtle.html#a630d157330f0ab2d3e8b1fb728b3bee2',1,'Turtle::Turtle(int width, int height, int gWidth, int gHeight, std::string title=&quot;Turtle&quot;)'],['../classTurtle.html#ac142fd07360e85d852424a66e15a37c0',1,'Turtle::Turtle(int width, int height, std::string title=&quot;Turtle&quot;)']]]
];
