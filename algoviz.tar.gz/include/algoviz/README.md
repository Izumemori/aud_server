# AlgoViz

AlgoViz is an [Jupyter Notebook](https://jupyter.org/) extension providing various classes and features
for the visualisation of algorithms and the use of graphical elements.

It provides a sidebar containing **views**. These are graphical element that can
be used to visualize data structures or directly manipulated by your program.
