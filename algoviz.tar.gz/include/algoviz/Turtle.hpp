/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef TURTLE_HPP
#define TURTLE_HPP

#include <iostream>
#include <cmath>
#include <string>
#include "xeus/xjson.hpp"
#include "nlohmann/json.hpp"
#include "SVG.hpp"


# define PI           3.14159265358979323846  /* pi */


/**
 * \class Turtle
 * \brief A drawing turtle.
 */
class Turtle : public SVG {

    protected:
        /// @private
        double x;
        /// @private
        double y;
        /// @private
        double alpha;
        /// @private
        string color;
        /// @private
        bool pen;
        /// @private
        int width;

        /// @private
        bool hidden;

        /// @private
        SVG *view;

        /// @private
        Path *turtle;
        /// @private
        // Path *turtle_triangle;
        /// @private
        Group *drawing;

        /**
         * \brief Initialize the SVG elements.
         */
        void init() {
            this->drawing = new Group(this->view);

            // Build Turtle
            this->turtle = new Path("M0 -5 L15 0 L0 5 Z",this->view); // new Group(this->view);
            // this->turtle_triangle = new Path("M0 -5 L15 0 L0 5 Z",this->view);
            // this->turtle->add(this->turtle_triangle);
            this->moveTo(this->x,this->y);
        }


        /**
         * \brief Update the View
         */
        void update() {
            string transform = 
            "translate(" + to_string(this->x) + "," + to_string(this->y) + ") rotate(" + to_string(this->alpha) + ")"; 
            this->turtle->setAttribute("transform",transform);

            if ( this->hidden ) {
                this->turtle->setAttribute("fill", "transparent");
                this->turtle->setAttribute("stroke", "transparent");
            } else {
                this->turtle->setAttribute("stroke", "black");
                if ( this->pen ) {
                    this->turtle->setAttribute("fill", this->color);
                } else {
                    this->turtle->setAttribute("fill", "transparent");
                }
            }

            this->turtle->toFront();
        }



    public:

        /**
         * \brief Create a Turtle view of the given size.
         * 
         * @param width The width in pixesl;
         * @param height The height in pixels.
         * @param gWidth The width of the frame containing the SVG (in grid spaces).
         * @param gHeight The width of the frame containing the SVG (in grid spaces).
         * @param title The title of the view.
         */
        Turtle(int width, int height, int gWidth, int gHeight, std::string title = "Turtle" ) : SVG(width,height,gWidth,gHeight,title) {
            AlgoViz::show();
            // int gw = width/this->colWidth + (width % this->colWidth > 0 ? 1 : 0);
            // int gh = height/this->rowHeight + (height % this->rowHeight > 0 ? 1 : 0);
            // this->view = new SVG(width,height,gw,gh,title);
            this->view = this;
            // this->id = view->getId();
            this->init();
            this->reset();
        }


        /**
         * \brief Create a Turtle view of the given size.
         * 
         * @param width The width in pixesl;
         * @param height The height in pixels.
         * @param title The title of the view.
         */
        Turtle(int width, int height, std::string title = "Turtle" ) : SVG(width,height,title) {
            AlgoViz::show();
            // int gw = width/this->colWidth + (width % this->colWidth > 0 ? 1 : 0);
            // int gh = height/this->rowHeight + (height % this->rowHeight > 0 ? 1 : 0);
            // this->view = new SVG(width,height,gw,gh,title);
            this->view = this;
            // this->id = view->getId();
            this->init();
            this->reset();
        }


        /**
         * \brief Move the turtle to the given position
         * 
         * @param x The x-coordinate of the target position
         * @param y The y-coordinate of the target position
         */
        void moveTo( double x , double y ) {
            this->x = x;
            this->y = y;
            this->update();
        }


        /**
        * \brief Rotate the turtle to the given absolute angle. 
        * 0 is pointing right.
        * Positive direction is clockwise.
        * 
        * @param alpha The absolute angle
        */
        void rotateTo( double alpha ) {
            this->alpha = alpha;
            while ( this->alpha < 0 ) this->alpha += 360;
            while ( this->alpha > 360 ) this->alpha -= 360;
            this->update();
        }

        /**
         * \brief Move the turtle forward and draw a line if the pen is down.
         * 
         * @param dist The distance the turtle should be moved.
         */
        void forward( double dist ) {
            double rad = 2.0*PI*(270+this->alpha)/360.0; 
            double dx = -sin(rad) * dist;
            double dy = cos(rad) * dist;

            if ( this->pen ) {   
                auto obj = xeus::xjson::object();
                obj["form"] = "line";
                obj["attrs"] = { "x1","y1","x2","y2","stroke","stroke-width"};
                obj["values"] = { this->x,this->y,this->x+dx,this->y+dy,this->color,this->width };
                this->drawing->add(obj);
            }

            this->moveTo(this->x+dx, this->y+dy);
        }
        

        /**
         * \brief Move the turtle backward and draw a line if the pen is down.
         * 
         * @param dist The distance the turtle should be moved.
         */
        void backward( double dist ) {
            double rad = 2.0*PI*(270+this->alpha)/360.0; 
            double dx = sin(rad) * dist;
            double dy = -cos(rad) * dist;

            if ( this->pen ) {   
                auto obj = xeus::xjson::object();
                obj["form"] = "line";
                obj["attrs"] = { "x1","y1","x2","y2","stroke","stroke-width"};
                obj["values"] = { this->x,this->y,this->x+dx,this->y+dy,this->color,this->width };
                this->drawing->add(obj);
            }

            this->moveTo(this->x+dx, this->y+dy);
        }


        /**
         * \brief Get the x-coordinate of current position.
         */
        double getX() {
            return this->x;        
        }

        /**
         * \brief Get the y-coordinate of current position.
         */
        double getY() {
            return this->y;        
        }

        /**
         * \brief Get the absoulte direction
         */
        double getDir() {
            return this->alpha;        
        }


        /**
         * \brief Turn the turtle clockwise.
         * 
         * @param delta The number of degrees the turtle should be turned.
         */
        void turn( double delta ) {
            this->alpha = this->alpha + delta;

            while ( this->alpha < 0 ) this->alpha += 360;
            while ( this->alpha > 360 ) this->alpha -= 360;

            this->update();
        }


        /**
         * \brief Set the drawing color.
         * 
         * @param color The color
         */
        void setColor( string color ) {
            this->color = color;
            this->update();
        }


        /**
         * \brief Set the width of the drawn lines.
         * 
         * @param width The width.
         */
        void setWidth( int width ) {
            this->width = width;
            this->update();
        }


        /**
         * \brief Raise the pen. 
         * The turtles doesn't draw if the pen is up.
         */
        void penUp() {
            this->pen = false;
            this->update();
        }


        /**
         * \brief Lower the pen and draw if moving.
         */
        void penDown() {
            this->pen = true;
            this->update();
        }


        /**
         * \brief Clear the drawing.
         * The position and direction are not reset.
         */
        void clear() {
            this->drawing->clear();

            // this->init();
            this->update();
        }


        /**
         * \brief Reset the turtle.
         * Clear the drawing and reset all parameters to their defaults.
         */
        void reset() {
            this->drawing->clear();

            this->x = this->view->getWidth()/2;
            this->y = this->view->getHeight()/2;
            this->alpha = 0;
            this->color = "black";
            this->pen = true;
            this->width = 1;
            this->hidden = false;

            // this->init();
            this->update();
        }


        /**
         * \brief Hide the turtle.
         */
        void hide() {
            this->hidden = true;
            this->update();
        }

        /**
         * \brief Hide the turtle.
         */
        void show() {
            this->hidden = false;
            this->update();
        }

}; // class Turtle


#endif // TURTLE_HPP