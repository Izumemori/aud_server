/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef ALGOVIZ_HPP
#define ALGOVIZ_HPP

#define ALGOVIZ_VERSION "2020-11-05-b"

#include <string>
#include <iostream>
#include <unistd.h>
#include <map>
#include <chrono>
#include "xcpp/xdisplay.hpp"
#include "xeus/xcomm.hpp"
#include "xeus/xinterpreter.hpp"
#include "xeus/xjson.hpp"
#include "xeus/xinput.hpp"
#include "nlohmann/json.hpp"

using namespace std;

/**
 * \brief Objects of this class represent a state of the mouse.
 * 
 * The objects contains information about the position of the mouse pointer
 * relative to the containig AlgoVizView and reltaive to the screen.
 * In addition the state of the mouse buttons is encoded.
 */
class MouseState
{

protected:
    /// @private
    int _x;
    /// @private
    int _y;
    /// @private
    int _screenX;
    /// @private
    int _screenY;
    /// @private
    int _buttons;

public:
    /// @private
    /**
     * \brief The standard constructor.
     */
    MouseState()
    {
        this->_x = -1;
        this->_y = -1;
        this->_screenX = -1;
        this->_screenY = -1;
        this->_buttons = -1;
    }

    /// @private
    /**
     * \brief Construct a MouseState object from a frontend message.
     */
    MouseState(const xeus::xjson &data)
    {
        this->_x = data["x"];
        this->_y = data["y"];
        this->_screenX = data["screenx"];
        this->_screenY = data["screeny"];
        this->_buttons = data["buttons"];
    }
    std::string m_content;

    /** 
     * \brief Get the x coordinate in the view.
     * @returns The x coordinate relative to the uper left corner of the view containing the mouse.
     */
    inline int x() { return this->_x; }

    /** 
     * \brief Get the x coordinate in the view.
     * @returns The x coordinate relative to the uper left corner of the view containing the mouse.
     */
    inline int y() { return this->_y; }

    /** 
     * \brief Get the x coordinate on the screen.
     * @returns The x coordinate relative to the uper left corner of the screen.
     */
    inline int screenX() { return this->_screenX; }

    /** 
     * \brief Get the y coordinate on the screen.
     * @returns The y coordinate relative to the uper left corner of the screen.
     */
    inline int screenY() { return this->_screenY; }

    /** 
     * \brief Get the state of the buttons.
     * 
     * The value is the sum of the codes for all three mouse buttons.
     * The left button has the value 0, the right button 2 and the middle button 1.
     * -1 indicates that no button was pressed.
     * 
     * @returns The sum of the values of pressed buttons.
     */
    inline int buttons() { return this->_buttons; }

    /**
     * \brief Check if the left button was pressed.
     * @returns true if the left button was pressed.
     */
    inline bool left() { return (this->_buttons == 0 ); }

    /**
     * \brief Check if the right button was pressed.
     * @returns true if the right button was pressed.
     */
    inline bool right() { return (this->_buttons == 2 ); }

    /**
     * \brief Check if the middle button was pressed.
     * @returns true if the middle button was pressed.
     */
    inline bool middle() { return (this->_buttons == 1 ); }

    /**
     * \brief Check if the mouse state is legal.
     * @returns true if the mouse state is legal.
     */
    inline bool isLegal() { return (this->_x >= 0); }
};


// ===============================================================================


/**
 * \class AlgoViz AlgoVizGlobal.hpp algoviz/AlgoViz.hpp
 * \brief This class controls the AlgoViz extensions.
 * 
 * To use the AlgoViz extensions in your program, you have to 
 * include one of the AlgoViz libraries:
 * 
 * \li `algoviz/AlgoViz.hpp` provides only the basic functionalities.
 * \li `algoviz/HTML.hpp` provides a simple way to display HTML.
 * \li `algoviz/SVG.hpp` is required for the manipulation of SVG graphics.
 * \li `algoviz/Turtle.hpp` provides the turtle graphics.
 *
 * To show or hide the sidebar, use
 * 
 *     AlgoViz::show();
 *     AlgoViz::hide();
 * 
 * `AlgoViz::clear()` removes all content from the sidebar.
 * 
 * Furthermore `AlgoViz` provides some useful functions.
 */
class AlgoViz
{


public:
    /// @private
    static std::chrono::time_point<std::chrono::steady_clock> lastMessageTime;

    /**
     * @brief Get the version of AlgoViz (currently the date of publication)
     */
    static std::string version();

    /**
      * Initialize AlgoViz.
      */
    /// @private
    static void init();

    /**
     * @brief Remove all views from the AlgoViz sidebar.
     */
    static void clear();

    /**
     * @brief Show the AlgoViz sidebar.
     */
    static void show();

    /**
     * @brief Hide the AlgoViz sidebar.
     */
    static void hide();

    /**
     * @brief Display a text message in the sidebar.
     * 
     * @param msg The text to be shown.
     */
    static void sendText(const std::string &msg);

    /**
     * @brief Wait for the given number of milliseconds.
     * 
     * @param msec The number of milliseconds to wait.
     */
    static inline void sleep(int msec);

    /** @private
       * @brief Send a json object describing an message to be shown.
       * 
       * @param msg The JSON Object describing the message.
       */
    static void sendMsg(const xeus::xjson &msg);


    /**
     * @brief Add an html string to the output of the cell.
     * 
     * @param content The HTML string
     */
    static void html(const std::string &content);


    /** @private
       * Add a slideshow to the output.
       * 
       * @param content The URL to the content (reative to the server)
       * @param server The basis URL of the viewer
       * @param width The width of the slideshow.
       * @param height The hight of the slidshow.
       */
    static void slideshow(const std::string &content, const std::string &server = "https://abbozza.informatik.uos.de/aud/slideshows/html/viewer.html", const std::string &width = "100%", const std::string &height = "700px");


    /**
     * @brief Create a CSS-Color-String.
     * 
     * This Operation retruns a CSS-Color string constructed from the given RGB-components.
     * These are values between 0 and 255. The alpha channel describes the opacity of the color with
     * 0.0 being fully transparent and 1.0 beeing fully opaque (default).
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    static std::string getColor(int red, int green, int blue, float alpha = 1.0);

    /// @private
    static void _slideshow(const std::string &id, const std::string &title, const std::string &content, const double ratio);

    /// @private
    inline static std::string lastMessage();

    /// @private
    static void handleMessage(const nl::json &msg);

    /// @private
    static std::string getMouse();

};

// =====================================================================================

/**
 * \class AlgoVizView View.hpp algoviz/AlgoViz.hpp
 * \brief An abstract View in the AlgoViz sidebar.
 * 
 * The size of views is either given in grid rows and columns (both 60 pixels wide)
 */
class AlgoVizView
{

public:
    /// @private
    static map<int, AlgoVizView *> views;
    /// @private
    static int nextViewID;

protected:
    /// @private
    int id;
    /// @private
    string type;
    /// @private
    int rowHeight = 80;
    /// @private
    int colWidth = 80;

public:

    virtual ~AlgoVizView() {}

    /**
     * \brief Create a view in the AlgoViz sidebar.
     * This constructor creates a view in the AlgoViz sidebar. The size is either given
     * in grid coumns and rows or pixels, depending on the type of view.
     * @param width The width of the view.
     * @param height The height of the view.
     * @param title The title of the view.
     */
    /// @private
    void create(int width, int height, std::string title = "")
    {
        this->id = AlgoVizView::nextViewID;
        AlgoVizView::views[this->id] = this;
        AlgoVizView::nextViewID++;

        auto msg = xeus::xjson::object();
        msg["type"] = this->type;
        msg["cmd"] = "create";
        msg["width"] = width;
        msg["height"] = height;
        msg["id"] = this->id;
        msg["title"] = title;
        AlgoViz::sendMsg(msg);
    }

    /**
     * Hide the view.
     * Remove the view from the AlgoViz sidebar. It is not
     * disposed and can still be manipulated and shown again.
     */
    void hide()
    {
        auto msg = xeus::xjson::object();
        msg["type"] = this->type;
        msg["cmd"] = "hide";
        msg["id"] = this->id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * Show the view.
     */
    void show()
    {
        auto msg = xeus::xjson::object();
        msg["type"] = this->type;
        msg["cmd"] = "show";
        msg["id"] = this->id;
        AlgoViz::sendMsg(msg);
    }

    /**
     * Clear the view.
     */
    virtual void clear()
    {
        auto msg = xeus::xjson::object();
        msg["type"] = this->type;
        msg["cmd"] = "clear";
        msg["id"] = this->id;
        AlgoViz::sendMsg(msg);
    }

    /// @private
    virtual void handleMessage(const nl::json &msg) {}


    /// @private
    static AlgoVizView *getView(int id)
    {
        if (AlgoVizView::views.find(id) != AlgoVizView::views.end())
        {
            return AlgoVizView::views[id];
        }
        return nullptr;
    }

    /// @private
    inline std::string toString()
    {
        return "View " + std::to_string(this->id);
    }

    /**
     * \brief Wait for the next keypress in the view.
     * 
     * The operation blocks the execution of the programm till a key was pressed.
     * In other words, the operation waits till the user pressed a key.
     * 
     * The view has to have focus to register the key press.
     * 
     * The operation returns a string containing the key name. The names are case
     * sensitive.
     * 
     * The modifiers are prepend in alphabetic order, eg. "Alt+Ctrl+Meta+A"
     *
     * @returns The key name.
     */
    std::string waitForKey()
    {
        return xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#GETKEY", false);
    }

    /**
     * \brief Get the name of the last key that was pressed in the view since the last call to lastKey().
     * 
     * The operation returns a string containing the name of the last key pressed.
     * The modifiers are prepend in alphabetic order, eg. "Alt+Ctrl+Meta+A"
     * 
     * After an execution of lastKey() it will return the emty string until a key was pressed again.
     *
     * @returns The key name.
     */
    std::string lastKey()
    {
        return xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#LASTKEY", false);
    }

    /**
     * \brief Get the current mouse state.
     * 
     * @returns The current mouse state.
     */
    MouseState getMouseState()
    {
        MouseState data;
        std::string datas = xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#MOUSE", false);
        try
        {
            xeus::xjson dataj = xeus::xjson::parse(datas);
            data = MouseState(dataj);
        }
        catch (...)
        {
        }
        return data;
    }

    /**
     * \brief Get the data of the last click inside the view.
     * 
     * @returns The state of the mouse at the last click.
     */
    MouseState lastClick()
    {
        MouseState data;
        std::string datas = xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#LASTCLICK", false);
        try
        {
            xeus::xjson dataj = xeus::xjson::parse(datas);
            data = MouseState(dataj);            
        }
        catch (...)
        {
            data = MouseState();
        }
        return data;
    }

    /**
     * \brief Wait for the next click in the view.
     * 
     * The operation blocks the execution of the program and waits till a click
     * is performed in the view.
     * 
     * @returns The state of the click.
     */
    MouseState waitForClick()
    {
        MouseState data;
        std::string datas = xeus::blocking_input_request("#ALGOVIZ#" + std::to_string(this->id) + "#GETCLICK", false);
        try
        {
            xeus::xjson dataj = xeus::xjson::parse(datas);
            data = MouseState(dataj);
            clicked(dataj);
        }
        catch (...)
        {
        }
        return data;
    }

    /// @private
    /**
     * \brief Get the ID of the view.
     */
    inline int getId()
    {
        return this->id;
    }

    /// @private 
    virtual void clicked(const xeus::xjson &data) {}

}; // class AlgoVizView


// =================================================================================


/// @private
map<int, AlgoVizView *> AlgoVizView::views = map<int, AlgoVizView *>();

/// @private
int AlgoVizView::nextViewID = 0;


// =================================================================================


namespace algoviz
{

    /// @private
    class CommHandler;

    /// @private
    algoviz::CommHandler *comm = nullptr;

    int nextViewID = 0;
    int nextScriptID = 0;

    /// @private
    struct html
    {
        inline html(const std::string &content)
        {
            m_content = content;
        }
        std::string m_content;
    };

    /// @private
    xeus::xjson mime_bundle_repr(const html &a)
    {
        auto bundle = xeus::xjson::object();
        bundle["text/html"] = a.m_content;
        return bundle;
    };

    /// @private
    struct script_t
    {
        inline script_t(const std::string &content)
        {
            m_content = content;
        }
        std::string m_content;
    };

    /// @private
    xeus::xjson mime_bundle_repr(const script_t &m)
    {
        auto bundle = xeus::xjson::object();
        auto id = std::string("algoviz") + std::to_string(nextViewID);
        bundle["text/html"] = std::string("<script id=\"" + id + "\">") + "try{AlgoViz.processMsg(" + m.m_content + ",\"" + id + "\");}catch(ex){}" + "</script>";
        nextViewID++;
        usleep(1000);
        return bundle;
    };

    /// @private
    class CommHandler
    {

    private:
        nl::json _data;
        xeus::xcomm *_comm;

    public:
        CommHandler()
        {
            xeus::get_interpreter()
                .comm_manager()
                .register_comm_target("algoviz", std::bind(&CommHandler::opened, this, std::placeholders::_1, std::placeholders::_2));
            this->_comm = new xeus::xcomm(xeus::get_interpreter().comm_manager().target("algoviz"), xeus::new_xguid());

            this->_comm->on_message(std::bind(&CommHandler::handleMessage, this, std::placeholders::_1));
            this->_comm->on_close(std::bind(&CommHandler::closed, this, std::placeholders::_1));

            nl::json metadata;
            nl::json data;
            data["foo"] = 42;
            this->_comm->open(std::move(metadata), std::move(data), xeus::buffer_sequence());
        }

        /// @private
        void opened(xeus::xcomm &&comm, const xeus::xmessage &msg) {}

        /// @private
        void closed(const xeus::xmessage &msg)
        {
            if (algoviz::comm == this)
            {
                algoviz::comm = nullptr;
            }
        }

        /// @private
        void handleMessage(const xeus::xmessage &msg)
        {
            const nl::json &content = msg.content();
            this->_data = content["data"];

            AlgoViz::handleMessage(this->_data);
        }

        /// @private
        inline xeus::xcomm *comm()
        {
            return this->_comm;
        }

        /// @private
        inline std::string lastReceived()
        {
            if (this->_data == nullptr)
                return "<null>";
            return this->_data.dump();
        }

        inline void send(const nl::json &data)
        {
            nl::json metadata;
            this->_comm->send(std::move(metadata), std::move(data), xeus::buffer_sequence());
        }
    };

}; // namespace algoviz


// ====================================================================================

std::chrono::time_point<std::chrono::steady_clock> AlgoViz::lastMessageTime;

std::string AlgoViz::version()
{
    return ALGOVIZ_VERSION;
}


/**
 ** Implementation of the methods of class AlgoViz
 **/

void AlgoViz::init()
{
    auto msg = xeus::xjson::object();
    msg["type"] = "init";
    AlgoViz::sendMsg(msg);
}

void AlgoViz::clear()
{
    AlgoViz::show();
    auto msg = xeus::xjson::object();
    msg["type"] = "clear";
    AlgoViz::sendMsg(msg);

    for (std::map<int,AlgoVizView*>::iterator it=AlgoVizView::views.begin(); it!=AlgoVizView::views.end(); ++it) {
        it->second->clear();
    }
    AlgoVizView::views.clear();
    AlgoVizView::nextViewID = 0;
}

void AlgoViz::show()
{
    auto msg = xeus::xjson::object();
    msg["type"] = "show";
    AlgoViz::sendMsg(msg);
    usleep(1000);
}

/**
       * Hide the AlgoViz sidebar.
       */
void AlgoViz::hide()
{
    auto msg = xeus::xjson::object();
    msg["type"] = "hide";
    AlgoViz::sendMsg(msg);
}

/**
       * Send a text message to be shown in the AlgoViz sidebar.
       * 
       * @param msg The text to be shown.
       */
void AlgoViz::sendText(const std::string &text)
{
    auto msg = xeus::xjson::object();
    msg["type"] = "msg";
    msg["content"] = text;
    // auto text = std::string("{ type: \"html\", content:\"") + msg + "\"}";
    // auto msgObj = algoviz::script_t(text);
    // xcpp::display(msgObj);
    AlgoViz::sendMsg(msg);
}

/**
     * \brief Wait for the given number of milliseconds.
     * 
     * @param msec The number of milliseconds to wait.
     */
inline void AlgoViz::sleep(int msec)
{
    usleep(1000 * msec);
}

/** @private
       * Send a json object describing an message to be shown.
       * 
       * @param msg The JSON Object describing the message.
       */
void AlgoViz::sendMsg(const xeus::xjson &msg)
{
    if (algoviz::comm == nullptr)
    {
        algoviz::comm = new algoviz::CommHandler();
        AlgoViz::lastMessageTime = chrono::steady_clock::now();
    }

    if ( msg["type"] != "#IGNORE") {
        auto now = chrono::steady_clock::now();
        auto dur = chrono::duration_cast<chrono::microseconds>(now - AlgoViz::lastMessageTime).count();
        if ( dur < 1500.0 ) {
            usleep((1500.0-dur));
        }
        algoviz::comm->send(msg);
        AlgoViz::lastMessageTime = chrono::steady_clock::now();
    }
}

/** @private
       * Add an html string to the output.
       * 
       * @param content The HTML string
       */
void AlgoViz::html(const std::string &content)
{
    auto obj = algoviz::html(content);
    xcpp::display(obj);
}


void AlgoViz::slideshow(const std::string &content, const std::string &server, const std::string &width, const std::string &height)
{
    auto text = std::string("<div class='slideshow'>") + "<div  style=\"display:block\"><iframe src=\"" + server + "?" + content + "\" width='" + width + "' height='" + height + "'></iframe></div>" + "<div class='collapsebtn' style='position:absolute;top:0px;right:0px' onclick='" + "   console.log(\"CLICK\");" + "   console.log(this.previousSibling);" + "   console.log(this.previousSibling.style);" + "   if ( this.previousSibling.style.display==\"none\") {" + "      this.previousSibling.style.display=\"block\";" + "   } else {" + "      this.previousSibling.style.display=\"none\";" + "   }'><i class=\"fa fa-eye-slash fa-2x\"></i></div>" + "</div>";
    auto obj = algoviz::html(text);
    xcpp::display(obj);
}


std::string AlgoViz::getColor(int red, int green, int blue, float alpha)
{
    return "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) + ")";
}


void AlgoViz::_slideshow(const std::string &id, const std::string &title, const std::string &content, const double ratio)
{
    auto text = std::string("<div class='slideshowContainer' id='" + id + "'></div><script>AlgoViz.injectSlideshow('" + id + "','" + title + "','" + content + "'," + std::to_string(ratio) + ")</script>");
    auto obj = algoviz::html(text);
    xcpp::display(obj);
}


void AlgoViz::handleMessage(const nl::json &msg)
{
    // AlgoViz::sendMsg(msg);

    int id = msg["view"];

    if (msg["view"] != -1)
    {
        AlgoVizView *view = AlgoVizView::getView(msg["view"]);
        if (view != nullptr)
        {
            view->handleMessage(msg);
            return;
        }
    }
}


std::string AlgoViz::lastMessage()
{
    return algoviz::comm->lastReceived();
}

#endif