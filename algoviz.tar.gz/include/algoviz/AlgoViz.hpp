/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef ALGOVIZ_HPP
#define ALGOVIZ_HPP


#include <string>
#include <iostream>
#include <unistd.h>
#include "xcpp/xdisplay.hpp"
#include "xeus/xjson.hpp"
#include "nlohmann/json.hpp"


using namespace std;


namespace algoviz {

    int nextViewID = 0;
    int nextScriptID = 0;

    /// @private
    struct html {   
        inline html(const std::string& content)
        {
            m_content = content;
        }
        std::string m_content;
    };

    /// @private
    xeus::xjson mime_bundle_repr(const html& a) {
        auto bundle = xeus::xjson::object();
        bundle["text/html"] = a.m_content;
        return bundle;
    };


    /// @private
    struct script_t {
        inline script_t(const std::string& content)
        {
            m_content = content;
        }
        std::string m_content;
    };

    /// @private
    xeus::xjson mime_bundle_repr(const script_t& m) {
        auto bundle = xeus::xjson::object();
        auto id = std::string("algoviz") + std::to_string(nextViewID);
        bundle["text/html"] = std::string("<script id=\"" + id + "\">")
        + "try{AlgoViz.processMsg(" + m.m_content + ",\"" + id + "\");}catch(ex){}"
        + "</script>";
        nextViewID++;
        usleep(1000);
        return bundle;
    };


}; // namespace algoviz

/**
 * \class AlgoViz AlgoVizGlobal.hpp algoviz/AlgoViz.hpp
 * \brief This class controls the AlgoViz sidebar.
 * 
 * It provides operations to control the AlgoViz sidebar.
 * To use the AlgoViz sidebar in your program, you have to 
 * include the library:
 * 
 *     #include <algoviz/AlgoViz.hpp>
 * 
 * To show or hide the sidebar, use
 * 
 *     AlgoViz::show();
 *     AlgoViz::hide();
 * 
 * You can add a \ref AlgoVizView or an \ref SVG to the sidebar.
 */
class AlgoViz {

   public:
     /**
      * Initialize AlgoViz.
      */
     /// @private
     static void init() {
        auto msg = xeus::xjson::object();
        msg["type"] = "init";
        AlgoViz::sendMsg(msg);
      }

      /**
       * Remove all views from the AlgoViz sidebar.
       */
      static void clear() {
        auto msg = xeus::xjson::object();
        msg["type"] = "clear";
        AlgoViz::sendMsg(msg);
      }

      /**
       * Show the AlgoViz sidebar.
       */
      static void show() {
        auto msg = xeus::xjson::object();
        msg["type"] = "show";
        AlgoViz::sendMsg(msg);
      }

      /**
       * Hide the AlgoViz sidebar.
       */
      static void hide() {
        auto msg = xeus::xjson::object();
        msg["type"] = "hide";
        AlgoViz::sendMsg(msg);
      }

      /**
       * Send a text message to be shown in the AlgoViz sidebar.
       * 
       * @param msg The text to be shown.
       */
      static void sendText(const std::string& msg) {
          auto text = std::string("{ type: \"html\", content:\"") + msg + "\"}";
          auto msgObj = algoviz::script_t(text);
          xcpp::display(msgObj);
      }

      /** @private
       * Send a json object describing an message to be shown.
       * 
       * @param msg The JSON Object describing the message.
       */
      static void sendMsg(const xeus::xjson& msg) {
          auto msgObj = algoviz::script_t(msg.dump());
          auto test = xeus::xjson::object();
          test["tags"] = { "algoviz_output" };
          using ::xcpp::mime_bundle_repr;
          xeus::get_interpreter().display_data(
              mime_bundle_repr(msgObj),
              test,
              nl::json::object()
          );
      }



      /** @private
       * Add an html string to the output.
       * 
       * @param content The HTML string
       */
      static void html(const std::string& content) {
          auto obj = algoviz::html(content);
          xcpp::display(obj);
      }



      /** @private
       * Add a slideshow to the output.
       * 
       * @param content The URL to the content (reative to the server)
       * @param server The basis URL of the viewer
       * @param width The width of the slideshow.
       * @param height The hight of the slidshow.
       */
      static void slideshow(const std::string& content, const std::string& server = "https://abbozza.informatik.uos.de/aud/slideshows/html/viewer.html", const std::string& width = "100%", const std::string& height="700px") {
          auto text  = std::string("<div class='slideshow'>")
                     + "<div  style=\"display:block\"><iframe src=\"" + server + "?" + content + "\" width='" + width + "' height='" + height + "'></iframe></div>"
                     + "<div class='collapsebtn' style='position:absolute;top:0px;right:0px' onclick='"
                     + "   console.log(\"CLICK\");"
                     + "   console.log(this.previousSibling);"
                     + "   console.log(this.previousSibling.style);"
                     + "   if ( this.previousSibling.style.display==\"none\") {"
                     + "      this.previousSibling.style.display=\"block\";"
                     + "   } else {"
                     + "      this.previousSibling.style.display=\"none\";"
                     + "   }'><i class=\"fa fa-eye-slash fa-2x\"></i></div>"
                     + "</div>";
          auto obj = algoviz::html(text);
          xcpp::display(obj);
      }


    /**
     * \brief Create a CSS-Color-String.
     * 
     * This Operation retruns a CSS-Color string constructed from the given RGB-components.
     * These are values between 0 and 255. The alpha channel describes the opacity of the color with
     * 0.0 being fully transparent and 1.0 beeing fully opaque (default).
     * 
     * @param red The red component ( 0 .. 255 )
     * @param green The green component ( 0 .. 255 )
     * @param blue The blue component ( 0 .. 255 )
     * @param alpha The opacity ( 0.0 .. 1.0 )
     */
    static std::string getColor(int red, int green, int blue, float alpha = 1.0) {
        return "rgba(" + std::to_string(red) + "," + std::to_string(green) + "," + std::to_string(blue) + "," + std::to_string(alpha) +  ")";
    }


    static void _slideshow(const std::string& id, const std::string& title, const std::string& content, const double ratio) {
        /* server = "https://abbozza.informatik.uos.de/aud/slideshows/html/viewer.html", const std::string& width = "100%", const std::string& height="700px") {
        auto text  = std::string("<div class='slideshow'>")
                  + "<div  style=\"display:block\"><iframe src=\"" + server + "?" + content + "\" width='" + width + "' height='" + height + "'></iframe></div>"
                  + "<div class='collapsebtn' style='position:absolute;top:0px;right:0px' onclick='"
                  + "   console.log(\"CLICK\");"
                  + "   console.log(this.previousSibling);"
                  + "   console.log(this.previousSibling.style);"
                  + "   if ( this.previousSibling.style.display==\"none\") {"
                  + "      this.previousSibling.style.display=\"block\";"
                  + "   } else {"
                  + "      this.previousSibling.style.display=\"none\";"
                  + "   }'><i class=\"fa fa-eye-slash fa-2x\"></i></div>"
                  + "</div>";
        */
        auto text = std::string("<div class='slideshowContainer' id='" + id + "'></div><script>AlgoViz.injectSlideshow('" + id + "','" + title + "','" + content + "'," + std::to_string(ratio) + ")</script>");
        auto obj = algoviz::html(text);
        xcpp::display(obj);
    }

};

#endif