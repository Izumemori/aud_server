/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


class Receiver {

    id = null;
    socket = null;
    sender = null;
    conn = null;
    data = null;
    callback = null;
    msgHandlers = [];


    static configuration = {
        iceServers : [{ urls : 'stun:stun.l.google.com:19302' }]
    };


    /**
     * Constructor
     * 
     * @param {string} ownId The own id fpr communication
     * @param {string} senderId The id of the sender
     * @param {socket.io.socket} socket The socket.io socket for signaling
     * @param {*} offer The received offer
     */
    constructor(ownId, senderId, socket) {
        this.socket = socket;
        this.id = ownId;
        this.sender = senderId;
    }



    handleOffer(offer, streams = []) {
        this.conn = new RTCPeerConnection(this.configuration);

        this.conn.ontrack = (event) => {
            this.ontrack(event.track);
        }


        this.conn.ondatachannel = (event) => {
            console.log("[Receiver " + this.id +"] Received message on data channel");
            if ( event.channel.label == "data" ) {
                this.data = event.channel;
                this.data.onmessage = (msg) => {
                        this.handleMessage(msg);
                }
            }
        }

        this.conn.onicecandidate = (event) => { 
            this.handleICE(event);
        };

        this.conn.onconnectionstatechange = (event) => {
            switch (this.conn.connectionState) {
                case "connected": 
                    this.onconnect(); 
                    break;
                case "disconnected":
                    this.ondisconnect(); 
                    break;
                case "failed":
                    this.onfail(); 
                    break;
                case "closed":
                    this.onclose(); 
                    break;
            }
        };
    
        this.socket.on("ice", (msg) => {
            this.conn.addIceCandidate(msg.candidate);
        });

        this.conn.setRemoteDescription(new RTCSessionDescription(offer));


        streams.forEach( (stream) => {
            stream.getTracks().forEach( (track) => {
                console.log("ADDING TRACK");
                this.conn.addTrack(track,stream);
            });
        });


        this.conn.createAnswer()
            .then( (answer) => {
                console.log("[Receiver " + this.id +"] Sending answer to " + this.sender );
                this.conn.setLocalDescription(answer);
                this.socket.emit("relay", {
                    to : this.sender,
                    type : "answer",
                    from : this.id,
                    answer : answer
                });
            })
            .catch( (err) => {
                console.error("[Receiver " + this.id +"] Error during the handling of an offer from " + msg.from);
                console.error(err);
            });
    }



    handleICE(event) {
        if (event.candidate) {
            this.socket.emit("relay", {
                type : "ice",
                to : this.sender,
                candidate : event.candidate,
                from : this.id
            });
        }        
    }


    ontrack(track) {
        console.log("[Receiver " + this.id +"] Default track handler");
    }




    /**
     * Send message via data channel.
     * 
     * @param {*} type 
     * @param {*} data 
     */
    send(type, data) {
        if ( this.data.readyState == "open" ) { 
            var obj = {
                type : type,
                data : data
            }
            this.data.send(JSON.stringify(obj));
        }
    }


    /**
     * Handle message received via data channel.
     * 
     * @param {event} msg 
     */
    handleMessage(msg) {
        try { 
            var obj = JSON.parse(msg.data);
            if ( this.msgHandlers[obj.type] != null ) {                
                this.msgHandlers[obj.type].call(this,obj.data);
            } else {
                console.error("[Sender] Unhandled message");
                console.error(obj);
            }
        } catch (err) {
            if ( this.msgHandlers[obj.type] != null ) {                
                this.msgHandlers[obj.type].call(this,msg);
            } else {
                console.error("[Sender] Unhandled message");
                console.error(msg);
            }
        }
    }

    on(type, handler) {
        this.msgHandlers[type] = handler;
    }




    onconnect() {}
    ondisconnect() {}
    onclose() {}
    onfail() {}

    close() {
        this.conn.close();
    }
    
}