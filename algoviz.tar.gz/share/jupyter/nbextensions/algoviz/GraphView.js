/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

class NodeView {

    id = -1;
    group = null;
    circle = null;
    text = null;
    label = null;
    view = null;

    constructor(id, view) {
        this.id = id;
        this.view = view;

        this.group = document.createElementNS("http://www.w3.org/2000/svg", "g");
        this.circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        this.text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        this.label = document.createElementNS("http://www.w3.org/2000/svg", "text");

        this.circle.setAttribute("cx",0);        
        this.circle.setAttribute("cy",0);        
        this.circle.setAttribute("r",20);        
        
        this.text.setAttribute("alignment-baseline","central");
        this.text.setAttribute("text-anchor","middle");
        this.text.setAttribute("x",0);        
        this.text.setAttribute("y",0);        

        this.label.setAttribute("alignment-baseline","left");
        this.label.setAttribute("text-anchor","bottom");
        this.label.setAttribute("x",20);        
        this.label.setAttribute("y",10);        

        this.group.appendChild(this.circle);
        this.group.appendChild(this.text);
        this.group.appendChild(this.label);

        this.view.svg.appendChild(this.group);
    }
}


class EdgeView {
}



class GraphView {

    id = -1;
    nodes = [];
    edges = [];
    view = null;

    static views = [];


    static handle(msg) {
        var view;
        if ( msg.cmd == "create" ) {
            view = new GraphView();
            view.id = GraphView.views.length;
            GraphView.views.push(view);
            return;
        }


        view = GraphView.views[msg.id];
        
        if ( view == null ) {
            console.error("[AlgoViz] GraphView with id " + msg.id + " not found!");
            return;
        }

        if ( msg.cmd == "addnode" ) {
            view.addNode(msg);
        } else if ( msg.cmd == "movenode" ) {
            view.moveNode(msg); 
        } else if ( msg.cmd == "nodeattr" ) {
            view.setNodeAttr(msg);
        } else if ( msg.cmd == "addedge" ) {
            view.addEdge(msg);
        } else if ( msg.cmd == "edgeattr" ) {
            view.setEdgeAttr(msg);
        }
    }


    constructor(view) {
        this.view = view;
        this.id = GraphView.views.length;
        GraphView.views.push(this);

        nodes = [];
        edges = [];
    }



    addNode(msg) {
        var id = msg.nid;
        var node = this.nodes[id];

        if ( node == null ) {
            node = new NodeView(this.nodes.length, this);
            this.nodes[id] = node;
        }
    }


    moveNode(msg) {        
    }

    setNodeAttr(msg) {
    }


    addEdge(msg) {
        var id = msg.eid;
        var uid = msg.uid;
        var vid = msg.vid;
        var edge = this.edges[id];

        if ( edge == null ) {
            edge = new NodeView(this.nodes.length, this);
            this.edges[id] = edge;
        }
    }

    setEdgeAttr(msg) {        
    }

}

