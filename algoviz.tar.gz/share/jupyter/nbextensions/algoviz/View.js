/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */



class View {

   gridWidth = 1;
   gridHeight = 1;
   id = "";
   handlers = [];
   div = null;
   content = null;
   parent = null;
   hidden = true;

   constructor(id,w,h) {
      this.id = id;
      this.gridWidth = w;
      this.gridHeight = h;

      this.handlers["set"] = this.handleSet;
      this.handlers["add"] = this.handleAdd;
      this.handlers["show"] = this.show;
      this.handlers["hide"] = this.hide;
      this.handlers["style"] = this.handleStyle;


      var viewDiv = document.createElement("div");
      viewDiv.className = "algoviz-view";
      viewDiv.id = "algoviz-view-" + id;
      viewDiv.style.gridColumnStart = "auto";
      viewDiv.style.gridRowStart = "auto";
      viewDiv.style.gridColumnEnd = "span " + w;
      viewDiv.style.gridRowEnd = "span " + h;
      this.div = viewDiv;

      this.content = document.createElement("div");
      this.content.className = "algoviz-view-content";

      this.div.appendChild(this.content);
   };


   show() {
      if ( (this.parent != null) && (this.hidden == true) ) { 
         this.hidden = false;
         this.parent.append(this.div);
      }
   };


   hide() {
      this.hidden = true;
      this.parent = this.div.parentNode;
      if ( this.div.parentNode != null ) this.div.parentNode.removeChild(this.div);
   };


   /**
    * Generic message handler
    * 
    * @param {JSON} msg 
    */
   handle(msg,parent) {         
      var handler = this.handlers[msg.cmd];
      if ( handler != null ) {    
         handler.call(this,msg);
      } else {
         if ( msg.cmd == "close" ) this.close(); 
         else if ( msg.cmd == "show" ) this.show(parent); 
      }
   };


   handleSet(msg) {
      this.content.innerHTML = msg.content;
   };


   handleAdd(msg) {
      var content = this.content.innerHTML + msg.content;
      this.content.innerHTML = content;
   };


   handleStyle(msg) {
      this.content.style[msg.name] = msg.value;
   };

}


class SVGView extends View {

    svg = null;
    elements = null;
 
    constructor(id,w,h,gw,gh) {
       super(id,gw,gh);
       this.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
       this.svg.setAttribute("width",w);
       this.svg.setAttribute("height",h);
       this.content.appendChild(this.svg);
       this.elements = [];
 
       this.handlers["add"] = this.addElement;
       this.handlers["clone"] = this.cloneElement;
       this.handlers["remove"] = this.removeElement;
       this.handlers["clear"] = this.clear;
       this.handlers["style"] = this.handleStyle;
       this.handlers["attr"] = this.handleAttr;
       this.handlers["attrs"] = this.handleAttrs;
       this.handlers["rotate"] = this.handleRotate;
       this.handlers["style"] = this.handleStyle;
       this.handlers["tofront"] = this.toFront;
       this.handlers["viewbox"] = this.handleViewBox;
       this.handlers["addChild"] = this.handleAddChild;
       this.handlers["removeChild"] = this.handleRemoveChild;
       this.handlers["empty"] = this.handleEmpty;
       this.handlers["settext"] = this.handleSetText;
       this.handlers["fit"] = this.fitToContent;
    }
 
 
    add(element) {
       if (element.id != -1) {
          if ( this.elements[element.id] == null ) {
            this.elements[element.id] = element;
            this.svg.appendChild(element.svg);
            element.parent = this;
          }
       } else {
         // Aonymous element
         this.svg.appendChild(element.svg);
         element.parent = this;
       }
    }
 
 
    remove(element) {
       var i = this.elements.indexOf(element);
      if ( i != -1 ) {
         this.elements[i] = null;
         this.svg.removeChild(element.svg);
      }
    }


    clear() {
       while ( this.svg.firstChild != null) {
          this.svg.removeChild(this.svg.firstChild);
       }
       this.elements = [];
    }
 
 

    addElement(msg,parent) {
        var el = new SVGElement(msg);
        this.add(el);
    }

   cloneElement(msg,parent) {
      var original = this.elements[msg.original];
      if ( original == null ) return;

      var el = new SVGElement(original,msg.eid);
      this.add(el);      
   }

   removeElement(msg,parent) {
      var el = this.elements[msg.eid];
      this.remove(el);
   }

    handleStyle(msg,parent) {
       var el = this.elements[msg.eid];
       if ( el == null ) return;
       el.setStyle(msg.name,msg.value);
    }
 
    handleStyle(msg,parent) {
      var el = this.elements[msg.eid];
      if ( el == null ) return;
      el.setStyle(msg.style,msg.value);
   }

    handleAttr(msg,parent) {
      var el = this.elements[msg.eid];
       if ( el == null ) return;
       el.setAttr(msg.attr,msg.value);
    }
 

    handleAttrs(msg,parent) {
      var el = this.elements[msg.eid];
      if ( el == null ) return;
      el.setAttrs(msg.attrs,msg.values);
   }


   handleRotate(msg,parent) {
      var el = this.elements[msg.eid];
      if ( el == null ) return;
      var bbox = el.svg.getBBox();
      var rx = bbox.x + bbox.width/2;
      var ry = bbox.y + bbox.height/2;
      var angle = msg.angle;
      el.setAttr("transform","rotate(" + angle + "," + rx + "," + ry + ")");
   }


   handleViewBox(msg,parent) {
      this.svg.setAttribute("viewBox",msg.coords);
   }


   handleAddChild(msg,parent) {
      if ( msg.childid != -1 ) {
         var el = this.elements[msg.eid];
         var child = this.elements[msg.childid];
         el.svg.appendChild(child.svg);
      } else {
         var el = this.elements[msg.eid];
         // create anonymous child
         // Masquerade group id
         msg.eid = -1;
         var child = new SVGElement(msg);
         el.svg.appendChild(child.svg);   
      }
   }


   handleRemoveChild(msg,parent) {
      var el = this.elements[msg.eid];
      var child = this.elements[msg.childid];
      el.svg.removeChild(child.svg);
   }

   handleEmpty(msg,parent) {
      var el = this.elements[msg.eid];
      while ( el.svg.firstChild != null) {
         el.svg.removeChild(el.svg.firstChild);
      }
   }

   toFront(msg,parent) {
      var el = this.elements[msg.eid];
      if ( el == null ) return;
      this.svg.removeChild(el.svg);
      this.svg.appendChild(el.svg);
   }


   handleSetText(msg,parent) {
      var el = this.elements[msg.eid];
      if ( el == null ) return;
      el.svg.textContent = msg.content;
   }


   fitToContent() {
      var svg = this.svg;
      var  bbox = svg.getBBox();
      // Update the width and height using the size of the contents
      if ( bbox.width > 500 ) 
         svg.setAttribute("width", bbox.x + bbox.width + bbox.x);
      // svg.setAttribute("height", bbox.y + bbox.height + bbox.y);
   }

 }
 


 
 class SVGElement {
 
    svg = null;
    id = -1;
    parent = null;
    dragging = false;
    svgTitle = null;
 
    constructor(msg, id = -1 ) {
      if ( id == -1 ) {
         this.id = msg.eid;
         this.svg = document.createElementNS("http://www.w3.org/2000/svg", msg.form);
       
         if ( msg.content != null ) {
            this.svg.textContent = msg.content;
         }

         if ( (msg.form != "text") && ( msg.form != "g") ) {
            this.svg.setAttribute("stroke","black");
            this.svg.setAttribute("stroke-width","1");
            this.svg.setAttribute("fill","black");
         }

         this.setAttrs(msg.attrs,msg.values);
      } else {
         var original = msg;
         this.id = id;
         this.svg = original.svg.cloneNode(true);
         this.parent = original.parent;
         this.svgTitle = original.svgTitle;
         this.parent.svg.appendChild(this.svg);
      }
    }

 

    set(names,msg) {
      for ( var i = 0; i < names.length; i++ ) {
         var val = msg[names[i]];
         if ( val != null ) {
            this.svg.setAtt(names[i],val);
         }
      }
    }
 

    setAttr(name,value) {
       if ( name == "title") {
         if ( this.svgTitle == null ) {
            this.svgTitle = document.createElementNS("http://www.w3.org/2000/svg", "title");
            this.svg.appendChild(this.svgTitle);
         }
         this.svgTitle.textContent = value;
       } else {
         this.svg.setAttribute(name,value);
       }
    }


    setAttrs(names,values) {
       if ( names == null ) return;
       for ( var i = 0; i < names.length; i++ ) {
          if ( values[i] != null ) {
             this.setAttr(names[i],values[i]);
          }
       }
    }

 
    setStyle(name,value) {
       this.svg.style[name] = value;
    }
 
 }
 