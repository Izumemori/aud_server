/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

 /**
 * AlgoViz
 * 
 * This extension provides a panel which can be used
 * for visualisations.
 * 
 */

define([
    'require',
    'base/js/namespace',
    'base/js/events'
], function (
    requirejs,
    Jupyter,
    events
) {
    //'use strict';
    
    var side_panel_connect_contract = null;
    var side_panel_inner = null;
    var algoviz_container = null;

    var side_panel_min_rel_width = 10;
    var side_panel_max_rel_width = 90;
    var side_panel_start_width = 45;

    var directConnection = false;
    var webSocket = null;
    var webSocketPort = 8090;

    var msgHandler = [];
    var views = [];
    
    function load_ipython_extension() {
        
        requirejs(['./View'], function () {
            console.log("[AlgoViz] View imported");
        } );

        // Inject stylsheet
        var link = document.createElement('link');
        link['rel'] = 'stylesheet';
        link.setAttribute('type','text/css');
        link.setAttribute('href', requirejs.toUrl('./AlgoViz.css'));
        document.head.appendChild(link);
        
        // Set handlers
        msgHandler["init_direct"] = handleInitDirect;
        msgHandler["clear"] = handleClear;
        msgHandler["msg"] = handleMsg;
        msgHandler["view"] = handleView;
        msgHandler["svg"] = handleSVG;

        var action = {
            icon: 'fa-pencil-square-o', // a font-awesome class used on buttons, etc
            help    : 'Show/Hide AlgoViz',
            help_index : 'zz',
            handler : toggleAlgoViz
        };
        var prefix = 'algoviz';
        var action_name = 'toggle';

        toggleAlgoViz();
        hideAlgoViz();
    
        var full_action_name = Jupyter.actions.register(action, action_name, prefix);
        Jupyter.toolbar.add_buttons_group([full_action_name]);
    };

    window.AlgoViz = {};

    window.AlgoViz.processMsg = function(msg) {
        directConnection = true;
        if ( msgHandler[msg.type] != null )  {
            msgHandler[msg.type](msg);
        } else {
            console.log("[AlgoViz] No handler found.");
        }

        // Conceal all traces
        var script = document.getElementById("algoviz_script");
        var parent = script.parentNode.parentNode;
        if ( parent ) {
            parent.parentNode.removeChild(parent);
        }
    }

    return {
        load_ipython_extension : load_ipython_extension
    };



    /**
     * Show/Hide the AlgoViz panel
     */
    function toggleAlgoViz() {
        var main_panel = $('#notebook_panel');
        var side_panel = $('#side_panel');

        if (side_panel.length < 1) {
            side_panel = $('<div id="side_panel"/>');
            build_side_panel(main_panel, side_panel,
                side_panel_min_rel_width, side_panel_max_rel_width);
            populate_side_panel(side_panel);
        }

        var visible = slide_side_panel(main_panel, side_panel);

        return visible;
    };



    function hideAlgoViz() {
        if (!side_panel.is(':hidden')) {        
            toggleAlgoViz();
        }
    }


    function showAlgoViz() {
        if (side_panel.is(':hidden')) {        
            toggleAlgoViz();
        }
    }


    /**
     * 
     * @param {*} port 
     */
    function openWebSocket(port, cont = false) {
        if ( directConnection == true ) {
            console.log("[AlgoViz] Direct connection established");
            side_panel_connect_contract.css({'background-color':'green'});
            side_panel_connect_contract.attr({title : 'Disconnect AlgoViz'});
            hideError();
            return;
        } 

        console.log("[AlgoViz] Trying to connect to port " + port);
        
        webSocketPort = port;

        if ( webSocket != null ) {
            return;
        }

        webSocket = new WebSocket("ws://localhost:" + webSocketPort,"algoviz");

        webSocket.onerror = function(error) {
            if ( !cont ) { 
                showError("<p><b>Could not establish connection to AlgoViz!</b></p><p>Start AlgoViz in your notebook:<code>\n"
                    +"import \{ AlgoViz \} from './lib/AlgoViz';\n"
                    +"let algoViz = new AlgoViz();\n"
                +"</code></p>");
            } else {
                setTimeout( () => { openWebSocket(webSocketPort,true); }, 1000 );
            }
            webSocket = null;
            side_panel_connect_contract.css({'background-color':'red'});
            side_panel_connect_contract.attr({title : 'Establish AlgoViz connection'});
        }

        
        webSocket.onopen = function(event) {
            side_panel_connect_contract.css({'background-color':'green'});
            side_panel_connect_contract.attr({title : 'Disconnect AlgoViz'});
            hideError();
        }


        webSocket.onmessage = function(event) {
            try {
                var msg = JSON.parse(event.data);
                if ( msgHandler[msg.type] != null )  {
                    msgHandler[msg.type](msg);
                } else {
                    console.log("[AlgoViz] No handler found.");
                }
            } catch (e) {     
                console.log(e);           
            }
        }

        webSocket.onclose = function(event) {
            openWebSocket(webSocketPort,true);
        }

        side_panel_connect_contract.css({'background-color':'red'});
        side_panel_connect_contract.attr({title : 'Establish AlgoViz connection'});
    }




    /**
     * Build the side panel
     * 
     * @param {*} main_panel 
     * @param {*} side_panel 
     * @param {*} min_rel_width 
     * @param {*} max_rel_width 
     */
    function build_side_panel(main_panel, side_panel, min_rel_width, max_rel_width) {
        if (min_rel_width === undefined) min_rel_width = 0;
        if (max_rel_width === undefined) max_rel_width = 100;

        side_panel.css('display','none');
        side_panel.insertAfter(main_panel);

        var side_panel_splitbar = $('<div class="side_panel_splitbar"/>');
        side_panel_inner = $('<div class="side_panel_inner"/>');
        side_panel_connect_contract = $('<i class="btn fa fa-plug hidden-print" style="background-color:red; color:white">');
        var side_panel_expand_contract = $('<i class="btn fa fa-expand hidden-print">');
        var side_panel_settings_contract = $('<i class="btn fa fa-cog hidden-print">');
        algoviz_container = $('<div class="algoviz_container"/>');

        side_panel.append(side_panel_splitbar);
        side_panel.append(side_panel_inner);
        side_panel.append(algoviz_container);

        side_panel_inner.append(side_panel_connect_contract);
        side_panel_inner.append(side_panel_expand_contract);
        side_panel_inner.append(side_panel_settings_contract);

        if ( webSocket != null ) {
            side_panel_connect_contract.css({'background-color':'green'});
            side_panel_connect_contract.attr({title : 'Disconnect AlgoViz'});
        } else {
            side_panel_connect_contract.css({'background-color':'red'});
            side_panel_connect_contract.attr({title : 'Establish AlgoViz connection'});
        }

        side_panel_connect_contract.attr({
            title: 'Establish connection',
            'data-toggle': 'tooltip'
        }).tooltip({
            placement: 'right'
        }).click( function() {
            if ( webSocket == null ) {
                openWebSocket(webSocketPort);
            } else {
                webSocket.close();
                webSocket = null;
                side_panel_connect_contract.css({'background-color':'red'});
                side_panel_connect_contract.attr({title : 'Establish AlgoViz connection'});
            }
        });


        side_panel_settings_contract.attr({
            title: 'Set port',
            'data-toggle': 'tooltip'
        }).tooltip({
            placement: 'right'
        }).click( function() {
            var port = prompt("Set AlgoViz port",webSocketPort);
            if ( port != null ) {
                webSocketPort = Math.round(Number(port));
            }
        });


        side_panel_expand_contract.attr({
            title: 'Expand/collapse AlgoViz',
            'data-toggle': 'tooltip'
        }).tooltip({
            placement: 'right'
        }).click(function () {
            var open = $(this).hasClass('fa-expand');
            var site = $('#site');
            slide_side_panel(main_panel, side_panel,
                open ? 100 : side_panel.data('last_width') || side_panel_start_width);
            $(this).toggleClass('fa-expand', !open).toggleClass('fa-compress', open);

            var tooltip_text = (open ? 'shrink to not' : 'expand to') + ' fill the window';
            if (open) {
                side_panel.insertAfter(site);
                site.slideUp();
                $('#header').slideUp();
                side_panel_inner.css({'margin-left': 0});
                side_panel_splitbar.hide();
            }
            else {
                side_panel.insertAfter(main_panel);
                $('#header').slideDown();
                site.slideDown({
                    complete: function() { events.trigger('resize-header.Page'); }
                });
                side_panel_inner.css({'margin-left': ''});
                side_panel_splitbar.show();
            }

            if (have_bs_tooltips) {
                side_panel_expand_contract.attr('title', tooltip_text);
                side_panel_expand_contract.tooltip('hide').tooltip('fixTitle');
            }
            else {
                side_panel_expand_contract.tooltip('option', 'content', tooltip_text);
            }
        });

        // bind events for resizing side panel
        side_panel_splitbar.mousedown(function (md_evt) {
            md_evt.preventDefault();
            $(document).mousemove(function (mm_evt) {
                mm_evt.preventDefault();
                var pix_w = side_panel.offset().left + side_panel.outerWidth() - mm_evt.pageX;
                var rel_w = 100 * (pix_w) / side_panel.parent().width();
                rel_w = rel_w > min_rel_width ? rel_w : min_rel_width;
                rel_w = rel_w < max_rel_width ? rel_w : max_rel_width;
                if ( side_panel.parent().width() - pix_w  > 300 ) {
                    main_panel.css('width', (100 - rel_w) + '%');
                    side_panel.css('width', rel_w + '%').data('last_width', rel_w);
                } else {
                    main_panel.css('width', "300px");
                }
            });
            return false;
        });
        $(document).mouseup(function (mu_evt) {
            $(document).unbind('mousemove');
        });

        return side_panel;
    };

    /**
     * Animate the appearance/disappearance of the side panel
     * 
     * @param {*} main_panel 
     * @param {*} side_panel 
     * @param {*} desired_width 
     */
    function slide_side_panel(main_panel, side_panel, desired_width) {

        var anim_opts = {
            step : function (now, tween) {
                main_panel.css('width', 100 - now + '%');
            }
        };

        if (desired_width === undefined) {
            if (side_panel.is(':hidden')) {
                desired_width = (side_panel.data('last_width') || side_panel_start_width);
            }
            else {
                desired_width = 0;
            }
        }

        var visible = desired_width > 0;
        if (visible) {
            main_panel.css({float: 'left', 'overflow-x': 'auto'});
            side_panel.show();
            var cont = document.getElementById('notebook-container');
            cont.style.maxWidth = "95%";
            cont.style.minWidth = "300px";
            openWebSocket(webSocketPort,true);
        }
        else {
            anim_opts['complete'] = function () {
                side_panel.hide();
                main_panel.css({float : '', 'overflow-x': '', width: ''});
            };
            var cont = document.getElementById('notebook-container');
            cont.style.maxWidth = "";
            cont.style.minWidth = "";
        }

        side_panel.animate({width: desired_width + '%'}, anim_opts);
        return visible;
    };


    function handleInitDirect(msg) {
        directConnection = true;
    }

    /**
     * 
     * @param {*} msg 
     */

    function handleClear(msg) {
        hideMessage();
        if ( views != null ) {
            for ( var i = 0; i < views.length; i++ ) {
                var view = views[i];
                view.close();
            }
        }
    }

    
    function handleMsg(msg) {
        showMessage(msg.content, msg.span);
    }


    function createView(id,width,height) {
        if ( views == null ) views = [];
        console.log("Create view with id " + id);
        var view = new View(id,width,height);
        algoviz_container.append(view.div);
        if ( views[id] != null ) {
            algoviz_container.remove(views[id].div);
        }
        views[id] = view;
    }


    function handleView(msg) {
        var view = views[msg.id];
        if  ( msg.cmd == "create" ) {
            createView(msg.id,msg.width,msg.height);
        } else if ( view != null ) {
            view.handle(msg,algoviz_container);
        } else {
            console.log("[AlgoViz] No view with id " + msg.id);
        }
    }


    function createSVGView(id,width,height) {
        if ( views == null ) views = [];
        console.log("Create SVG view with id " + id);
        var view = new SVGView(id,width,height);
        algoviz_container.append(view.div);
        if ( views[id] != null ) {
            algoviz_container.remove(views[id].div);
        }
        views[id] = view;
    }


    function handleSVG(msg) {
        console.log("handle SVG");
        var view = views[msg.id];
        if  ( msg.cmd == "create" ) {
            createSVGView(msg.id,msg.width,msg.height);
        } else if ( view !=  null ) {
            view.handle(msg,algoviz_container);
        } else {
            console.log("[AlgoViz] No view with id " + msg.id);
        }
    }

    

    /**
     * Fill the side panel with content
     * 
     * @param {} side_panel 
     */
    function populate_side_panel(side_panel) {
        var errPanel = $('<div class="algoviz_panel" id="algoviz-error"><i id="algoviz-error-icon" class="fa fa-exclamation-circle fa-3x" style="color:red"/><div id="algoviz-error-msg"></div></div>');
        algoviz_container.append(errPanel);
        var msgPanel = $('<div class="algoviz_panel" id="algoviz-message"><i id="algoviz-message-icon" class="fa fa-envelope-o fa-2x"/><div id="algoviz-message-msg"></div></div>');
        algoviz_container.append(msgPanel);
    };


    function showError(msg) {
        var errPanel = document.getElementById('algoviz-error');
        var errPanelMsg = document.getElementById('algoviz-error-msg');
        errPanelMsg.innerHTML = msg;
        errPanel.style.display = "flex";
    }

    function hideError() {        
        var errPanel = document.getElementById('algoviz-error');
        errPanel.style.display = "none";
    }


    function showMessage(msg,span = 1) {
        var panel = document.getElementById('algoviz-message');
        var panelMsg = document.getElementById('algoviz-message-msg');
        panel.style.gridRowEnd = "span " + span;
        panelMsg.innerHTML = msg;
        panel.style.display = "flex";
    }

    function hideMessage() {        
        var panel = document.getElementById('algoviz-message');
        panel.style.display = "none";
    }



});