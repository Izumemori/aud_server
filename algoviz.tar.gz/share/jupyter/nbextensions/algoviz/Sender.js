/* 
 * The MIT License
 *
 * Copyright 2020 Michael Brinkmeier, AG Didaktik der Informatik.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


class Sender {
    
    id = null;
    socket = null;
    receiver = null;
    conn = null;
    data = null;
    callback = null;
    msgHandlers = [];

    streams = [];

    static configuration = {
        iceServers : [{ urls : 'stun:stun.l.google.com:19302' }]
    };

    /**
     * Constructor
     * 
     * @param {string} ownId The own id fpr communication
     * @param {string} receiverId The id of the receiver
     * @param {socket.io.socket} socket The socket.io socket for signaling
     * @param {MediaStream[]} streams The streams to be send
     */
    constructor(ownId, receiverId, socket, streams) {
        this.socket = socket;
        this.id = ownId;
        this.receiver = receiverId;
        this.streams = streams;
    }


    /**
     * Send an offer to the receiver
     */
    sendOffer(type, details, callback = null) {
        this.callback = callback;
        this.conn = new RTCPeerConnection(this.configuration);

        this.socket.on("answer", (msg) => {addIceCandidate
                console.log("ACCEPTED");
                this.handleAnswer(msg);
            }
        });
        
        this.data = this.conn.createDataChannel("data");
        this.data.onmessage = (msg) =>  {
            this.handleMessage(msg);
        }

        this.streams.forEach( (stream) => {
            stream.getTracks().forEach( (track) => {
                this.conn.addTrack(track,stream);
            });
        });

        this.conn.onconnectionstatechange = (event) => {
            switch (this.conn.connectionState) {
                case "connected": 
                    this.onconnect(); 
                    break;
                case "disconnected":
                    this.ondisconnect(); 
                    break;
                case "failed":
                    this.onfail(); 
                    break;
                case "closed":
                    this.onclose(); 
                    break;
            }
        };

        this.conn.onicecandidate = (msg) => {
            this.handleICE(msg);
        }

        this.conn.ondatachannel = (event) => {
            console.log("[Sender " + this.id +"] Received message on data channel");
            this.data = event.channel;
            this.data.onmessage = (msg) => {
                this.handleMessage(msg);
            }
        }

        this.conn.ontrack = (event) => {
            console.log(event.track);
        }


        this.conn.createOffer()
            .then ( (offer) => {
                var myOffer= offer;
                this.conn.setLocalDescription(offer)
                    .then( (desc) => {
                        console.log("[Sender " + this.id + "] Sending offer to " + this.receiver);
                        this.socket.emit("relay", {
                            type : type,
                            to : this.receiver,
                            from : this.id,
                            offer : offer,
                            details : details
                        });
                    })
                    .catch( (err) => {
                        console.error("[Sender] Error while creating offer:");
                        console.error(err);   
                    })
            })
            .catch( (err) => {
                console.error("[Sender] Error while creating offer:");
                console.error(err);    
            });
    
    }



    handleAnswer(msg) {
        console.log("[Sender] " + this.id + " Answer received from driver " + msg.from);
        this.conn.setRemoteDescription(new RTCSessionDescription(msg.answer))
            .then( (desc) => {
                if ( this.callback ) {
                    this.callback.call(this,desc);
                }
            })   
            .catch( (err) => {
                console.error("[AlgoViz] Error during handling of answer");
                console.error(err);
            });
    }



    /**
     * Send an ICE candidate to the receiver.
     * 
     * @param {*} event 
     */
    handleICE(event) {
        if (event.candidate) {
            this.socket.emit("relay", {
                type : "ice",
                to : this.receiver,
                candidate : event.candidate,
                from : this.id
            });
        }        
    }



    /**
     * Send message via data channel.
     * 
     * @param {*} type 
     * @param {*} data 
     */
    send(type, data) {
        if ( this.data.readyState == "open" ) { 
            var obj = {
                type : type,
                data : data
            }
            this.data.send(JSON.stringify(obj));
        }
    }

    emit(type,data) {
        this.send(type,data);
    }


    /**
     * Handle message received via data channel.
     * 
     * @param {event} msg 
     */
    handleMessage(msg) {
        console.log(msg);
        try { 
            var obj = JSON.parse(msg.data);
            if ( this.msgHandlers[obj.type] != null ) {                
                this.msgHandlers[obj.type].call(this,obj);
            } else {
                console.error("[Sender] Unhandled message");
                console.log(obj);
            }
        } catch (err) {
            if ( this.msgHandlers[obj.type] != null ) {                
                this.msgHandlers[obj.type].call(this,msg);
            } else {
                console.error("[Sender] Unhandled message");
                console.log(msg);
            }
        }
    }

    on(type, handler) {
        this.msgHandlers[type] = handler;
    }


    onconnect() {}
    ondisconnect() {}
    onclose() {}

    onfail() {}

    
    close() {
        this.conn.close();
    }

}