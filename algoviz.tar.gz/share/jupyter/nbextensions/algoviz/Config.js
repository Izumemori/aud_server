var AlgoVizConfig = {

    broker : "http://localhost:8080",
    webcam : true
    
}

var file = fs.readFileSync("/etc/algoviz.json");
console.log(fileju          );

if ( localStorage.getItem("AlgoVizConfig") != null ) {
    try {
        AlgoVizConfig = JSON.parse(localStorage.getItem("AlgoVizConfig"));
    } catch (err) {        
    }
}
